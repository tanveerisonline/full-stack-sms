import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/useAuth";
import Landing from "@/pages/landing";
import Dashboard from "@/pages/dashboard";
import Students from "@/pages/students";
import Teachers from "@/pages/teachers";
import Attendance from "@/pages/attendance";
import Courses from "@/pages/courses";
import Grades from "@/pages/grades";
import Fees from "@/pages/fees";
import Reports from "@/pages/reports";
import Layout from "@/components/layout";
import NotFound from "@/pages/not-found";
import { AdminOnly, TeacherOrAdmin } from "@/components/auth/RoleGuard";

function Router() {
  const { isAuthenticated, isLoading, isAdmin, isTeacher, isStudent, isParent } = useAuth();

  return (
    <Switch>
      {isLoading || !isAuthenticated ? (
        <Route path="/" component={Landing} />
      ) : (
        <Layout>
          <Route path="/" component={Dashboard} />
          
          {/* Admin and Teacher routes */}
          <Route path="/students">
            <TeacherOrAdmin fallback={<NotFound />}>
              <Students />
            </TeacherOrAdmin>
          </Route>
          
          <Route path="/teachers">
            <AdminOnly fallback={<NotFound />}>
              <Teachers />
            </AdminOnly>
          </Route>
          
          <Route path="/attendance">
            <TeacherOrAdmin fallback={<NotFound />}>
              <Attendance />
            </TeacherOrAdmin>
          </Route>
          
          <Route path="/courses">
            <TeacherOrAdmin fallback={<NotFound />}>
              <Courses />
            </TeacherOrAdmin>
          </Route>
          
          <Route path="/grades">
            <TeacherOrAdmin fallback={<NotFound />}>
              <Grades />
            </TeacherOrAdmin>
          </Route>
          
          <Route path="/fees">
            <AdminOnly fallback={<NotFound />}>
              <Fees />
            </AdminOnly>
          </Route>
          
          {/* Reports accessible to all authenticated users but with role-based data restrictions */}
          <Route path="/reports" component={Reports} />
        </Layout>
      )}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
