import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { insertFeePaymentSchema, type InsertFeePayment, type FeePayment, type Student, type FeeStructure } from "@shared/schema";
import { z } from "zod";

const formSchema = insertFeePaymentSchema.extend({
  amount: z.coerce.number().positive("Amount must be greater than 0"),
  paymentDate: z.string().min(1, "Payment date is required"),
});

type FormData = z.infer<typeof formSchema>;

interface FeePaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  feePayment?: FeePayment | null;
  preSelectedStudent?: string;
  preSelectedFeeStructure?: string;
}

export default function FeePaymentModal({ 
  isOpen, 
  onClose, 
  feePayment, 
  preSelectedStudent,
  preSelectedFeeStructure 
}: FeePaymentModalProps) {
  const { toast } = useToast();
  const isEditing = !!feePayment;

  const { data: students } = useQuery<Student[]>({
    queryKey: ["/api/students"],
    enabled: isOpen,
  });

  const { data: feeStructures } = useQuery<FeeStructure[]>({
    queryKey: ["/api/fee-structure"],
    enabled: isOpen,
  });

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      studentId: "",
      feeStructureId: "",
      amount: 0,
      paymentDate: new Date().toISOString().split('T')[0],
      paymentMethod: "cash",
      status: "paid",
      dueDate: "",
      receiptNumber: "",
    },
  });

  useEffect(() => {
    if (feePayment) {
      form.reset({
        studentId: feePayment.studentId || "",
        feeStructureId: feePayment.feeStructureId || "",
        amount: Number(feePayment.amount) || 0,
        paymentDate: feePayment.paymentDate || "",
        paymentMethod: feePayment.paymentMethod || "cash",
        status: feePayment.status || "paid",
        dueDate: feePayment.dueDate || "",
        receiptNumber: feePayment.receiptNumber || "",
      });
    } else {
      form.reset({
        studentId: preSelectedStudent || "",
        feeStructureId: preSelectedFeeStructure || "",
        amount: 0,
        paymentDate: new Date().toISOString().split('T')[0],
        paymentMethod: "cash",
        status: "paid",
        dueDate: "",
        receiptNumber: `RCP-${Date.now()}`,
      });
    }
  }, [feePayment, preSelectedStudent, preSelectedFeeStructure, form]);

  const mutation = useMutation({
    mutationFn: async (data: FormData) => {
      if (isEditing) {
        await apiRequest("PUT", `/api/fee-payments/${feePayment.id}`, data);
      } else {
        await apiRequest("POST", "/api/fee-payments", data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/fee-payments"] });
      toast({
        title: "Success",
        description: `Fee payment ${isEditing ? "updated" : "recorded"} successfully`,
      });
      onClose();
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: `Failed to ${isEditing ? "update" : "record"} fee payment`,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: FormData) => {
    mutation.mutate(data);
  };

  // Auto-fill amount when fee structure is selected
  const watchedFeeStructureId = form.watch("feeStructureId");
  useEffect(() => {
    if (watchedFeeStructureId && feeStructures) {
      const selectedFeeStructure = feeStructures.find(fs => fs.id === watchedFeeStructureId);
      if (selectedFeeStructure && !isEditing) {
        form.setValue("amount", Number(selectedFeeStructure.amount));
      }
    }
  }, [watchedFeeStructureId, feeStructures, form, isEditing]);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle data-testid="text-modal-title">
            {isEditing ? "Edit Fee Payment" : "Record Fee Payment"}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="studentId">Student *</Label>
              <Select
                value={form.watch("studentId") || ""}
                onValueChange={(value) => form.setValue("studentId", value)}
              >
                <SelectTrigger data-testid="select-student">
                  <SelectValue placeholder="Select Student" />
                </SelectTrigger>
                <SelectContent>
                  {students?.map((student) => (
                    <SelectItem key={student.id} value={student.id}>
                      {student.firstName} {student.lastName} ({student.studentId})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="feeStructureId">Fee Type *</Label>
              <Select
                value={form.watch("feeStructureId") || ""}
                onValueChange={(value) => form.setValue("feeStructureId", value)}
              >
                <SelectTrigger data-testid="select-fee-structure">
                  <SelectValue placeholder="Select Fee Type" />
                </SelectTrigger>
                <SelectContent>
                  {feeStructures?.map((feeStructure) => (
                    <SelectItem key={feeStructure.id} value={feeStructure.id}>
                      {feeStructure.feeType} - ${feeStructure.amount}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="amount">Amount *</Label>
              <Input
                id="amount"
                type="number"
                step="0.01"
                min="0"
                {...form.register("amount", { valueAsNumber: true })}
                data-testid="input-amount"
              />
              {form.formState.errors.amount && (
                <p className="text-red-500 text-sm mt-1">
                  {form.formState.errors.amount.message}
                </p>
              )}
            </div>

            <div>
              <Label htmlFor="paymentDate">Payment Date *</Label>
              <Input
                id="paymentDate"
                type="date"
                {...form.register("paymentDate")}
                data-testid="input-payment-date"
              />
              {form.formState.errors.paymentDate && (
                <p className="text-red-500 text-sm mt-1">
                  {form.formState.errors.paymentDate.message}
                </p>
              )}
            </div>

            <div>
              <Label htmlFor="paymentMethod">Payment Method</Label>
              <Select
                value={form.watch("paymentMethod") || "cash"}
                onValueChange={(value) => form.setValue("paymentMethod", value)}
              >
                <SelectTrigger data-testid="select-payment-method">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cash">Cash</SelectItem>
                  <SelectItem value="card">Card</SelectItem>
                  <SelectItem value="online">Online Transfer</SelectItem>
                  <SelectItem value="check">Check</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="status">Status</Label>
              <Select
                value={form.watch("status") || "paid"}
                onValueChange={(value) => form.setValue("status", value)}
              >
                <SelectTrigger data-testid="select-status">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="paid">Paid</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="overdue">Overdue</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="dueDate">Due Date</Label>
              <Input
                id="dueDate"
                type="date"
                {...form.register("dueDate")}
                data-testid="input-due-date"
              />
            </div>

            <div>
              <Label htmlFor="receiptNumber">Receipt Number</Label>
              <Input
                id="receiptNumber"
                {...form.register("receiptNumber")}
                data-testid="input-receipt-number"
              />
            </div>
          </div>

          <div className="flex justify-end space-x-2 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              data-testid="button-cancel"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={mutation.isPending}
              data-testid="button-save"
            >
              {mutation.isPending
                ? "Saving..."
                : isEditing
                ? "Update Payment"
                : "Record Payment"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}