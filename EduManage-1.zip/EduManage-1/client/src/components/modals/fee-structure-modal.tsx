import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { insertFeeStructureSchema, type InsertFeeStructure, type FeeStructure, type Grade } from "@shared/schema";
import { z } from "zod";

const formSchema = insertFeeStructureSchema.extend({
  feeType: z.string().min(1, "Fee type is required"),
  amount: z.coerce.number().positive("Amount must be greater than 0"),
  academicYear: z.string().min(1, "Academic year is required"),
});

type FormData = z.infer<typeof formSchema>;

interface FeeStructureModalProps {
  isOpen: boolean;
  onClose: () => void;
  feeStructure?: FeeStructure | null;
}

export default function FeeStructureModal({ isOpen, onClose, feeStructure }: FeeStructureModalProps) {
  const { toast } = useToast();
  const isEditing = !!feeStructure;

  const { data: grades } = useQuery<Grade[]>({
    queryKey: ["/api/grades"],
    enabled: isOpen,
  });

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      gradeId: "",
      feeType: "",
      amount: 0,
      frequency: "monthly",
      academicYear: new Date().getFullYear().toString(),
    },
  });

  useEffect(() => {
    if (feeStructure) {
      form.reset({
        gradeId: feeStructure.gradeId || "",
        feeType: feeStructure.feeType || "",
        amount: Number(feeStructure.amount) || 0,
        frequency: feeStructure.frequency || "monthly",
        academicYear: feeStructure.academicYear || "",
      });
    } else {
      form.reset({
        gradeId: "",
        feeType: "",
        amount: 0,
        frequency: "monthly",
        academicYear: new Date().getFullYear().toString(),
      });
    }
  }, [feeStructure, form]);

  const mutation = useMutation({
    mutationFn: async (data: FormData) => {
      if (isEditing) {
        await apiRequest("PUT", `/api/fee-structure/${feeStructure.id}`, data);
      } else {
        await apiRequest("POST", "/api/fee-structure", data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/fee-structure"] });
      toast({
        title: "Success",
        description: `Fee structure ${isEditing ? "updated" : "created"} successfully`,
      });
      onClose();
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: `Failed to ${isEditing ? "update" : "create"} fee structure`,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: FormData) => {
    mutation.mutate(data);
  };

  const feeTypes = [
    "tuition",
    "transport",
    "library",
    "laboratory",
    "sports",
    "examination",
    "development",
    "other",
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle data-testid="text-modal-title">
            {isEditing ? "Edit Fee Structure" : "Add New Fee Structure"}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="gradeId">Grade/Class *</Label>
              <Select
                value={form.watch("gradeId") || ""}
                onValueChange={(value) => form.setValue("gradeId", value)}
              >
                <SelectTrigger data-testid="select-grade">
                  <SelectValue placeholder="Select Grade" />
                </SelectTrigger>
                <SelectContent>
                  {grades?.map((grade) => (
                    <SelectItem key={grade.id} value={grade.id}>
                      {grade.name} {grade.section && `- Section ${grade.section}`}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="feeType">Fee Type *</Label>
              <Select
                value={form.watch("feeType") || ""}
                onValueChange={(value) => form.setValue("feeType", value)}
              >
                <SelectTrigger data-testid="select-fee-type">
                  <SelectValue placeholder="Select Fee Type" />
                </SelectTrigger>
                <SelectContent>
                  {feeTypes.map((type) => (
                    <SelectItem key={type} value={type}>
                      {type.charAt(0).toUpperCase() + type.slice(1)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {form.formState.errors.feeType && (
                <p className="text-red-500 text-sm mt-1">
                  {form.formState.errors.feeType.message}
                </p>
              )}
            </div>

            <div>
              <Label htmlFor="amount">Amount *</Label>
              <Input
                id="amount"
                type="number"
                step="0.01"
                min="0"
                {...form.register("amount", { valueAsNumber: true })}
                data-testid="input-amount"
              />
              {form.formState.errors.amount && (
                <p className="text-red-500 text-sm mt-1">
                  {form.formState.errors.amount.message}
                </p>
              )}
            </div>

            <div>
              <Label htmlFor="frequency">Frequency</Label>
              <Select
                value={form.watch("frequency") || "monthly"}
                onValueChange={(value) => form.setValue("frequency", value)}
              >
                <SelectTrigger data-testid="select-frequency">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="monthly">Monthly</SelectItem>
                  <SelectItem value="quarterly">Quarterly</SelectItem>
                  <SelectItem value="yearly">Yearly</SelectItem>
                  <SelectItem value="one-time">One Time</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="md:col-span-2">
              <Label htmlFor="academicYear">Academic Year *</Label>
              <Input
                id="academicYear"
                placeholder="e.g., 2024-2025"
                {...form.register("academicYear")}
                data-testid="input-academic-year"
              />
              {form.formState.errors.academicYear && (
                <p className="text-red-500 text-sm mt-1">
                  {form.formState.errors.academicYear.message}
                </p>
              )}
            </div>
          </div>

          <div className="flex justify-end space-x-2 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              data-testid="button-cancel"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={mutation.isPending}
              data-testid="button-save"
            >
              {mutation.isPending
                ? "Saving..."
                : isEditing
                ? "Update Fee Structure"
                : "Add Fee Structure"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}