import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { insertCourseSchema, type InsertCourse, type Course, type Grade, type Teacher } from "@shared/schema";
import { z } from "zod";

const formSchema = insertCourseSchema.extend({
  name: z.string().min(1, "Course name is required"),
  code: z.string().min(1, "Course code is required"),
});

type FormData = z.infer<typeof formSchema>;

interface CourseModalProps {
  isOpen: boolean;
  onClose: () => void;
  course?: Course | null;
}

export default function CourseModal({ isOpen, onClose, course }: CourseModalProps) {
  const { toast } = useToast();
  const isEditing = !!course;

  const { data: grades } = useQuery<Grade[]>({
    queryKey: ["/api/grades"],
    enabled: isOpen,
  });

  const { data: teachers } = useQuery<Teacher[]>({
    queryKey: ["/api/teachers"],
    enabled: isOpen,
  });

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      code: "",
      description: "",
      credits: 1,
      gradeId: "",
      teacherId: "",
    },
  });

  useEffect(() => {
    if (course) {
      form.reset({
        name: course.name || "",
        code: course.code || "",
        description: course.description || "",
        credits: course.credits || 1,
        gradeId: course.gradeId || "",
        teacherId: course.teacherId || "",
      });
    } else {
      form.reset({
        name: "",
        code: "",
        description: "",
        credits: 1,
        gradeId: "",
        teacherId: "",
      });
    }
  }, [course, form]);

  const mutation = useMutation({
    mutationFn: async (data: FormData) => {
      if (isEditing) {
        await apiRequest("PUT", `/api/courses/${course.id}`, data);
      } else {
        await apiRequest("POST", "/api/courses", data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/courses"] });
      toast({
        title: "Success",
        description: `Course ${isEditing ? "updated" : "created"} successfully`,
      });
      onClose();
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: `Failed to ${isEditing ? "update" : "create"} course`,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: FormData) => {
    mutation.mutate(data);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle data-testid="text-modal-title">
            {isEditing ? "Edit Course" : "Add New Course"}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="name">Course Name *</Label>
              <Input
                id="name"
                {...form.register("name")}
                data-testid="input-course-name"
              />
              {form.formState.errors.name && (
                <p className="text-red-500 text-sm mt-1">
                  {form.formState.errors.name.message}
                </p>
              )}
            </div>

            <div>
              <Label htmlFor="code">Course Code *</Label>
              <Input
                id="code"
                {...form.register("code")}
                data-testid="input-course-code"
              />
              {form.formState.errors.code && (
                <p className="text-red-500 text-sm mt-1">
                  {form.formState.errors.code.message}
                </p>
              )}
            </div>

            <div>
              <Label htmlFor="credits">Credits</Label>
              <Input
                id="credits"
                type="number"
                min="1"
                {...form.register("credits", { valueAsNumber: true })}
                data-testid="input-credits"
              />
            </div>

            <div>
              <Label htmlFor="gradeId">Grade/Class</Label>
              <Select
                value={form.watch("gradeId") || ""}
                onValueChange={(value) => form.setValue("gradeId", value)}
              >
                <SelectTrigger data-testid="select-grade">
                  <SelectValue placeholder="Select Grade" />
                </SelectTrigger>
                <SelectContent>
                  {grades?.map((grade) => (
                    <SelectItem key={grade.id} value={grade.id}>
                      {grade.name} {grade.section && `- Section ${grade.section}`}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="teacherId">Teacher</Label>
              <Select
                value={form.watch("teacherId") || ""}
                onValueChange={(value) => form.setValue("teacherId", value)}
              >
                <SelectTrigger data-testid="select-teacher">
                  <SelectValue placeholder="Select Teacher" />
                </SelectTrigger>
                <SelectContent>
                  {teachers?.map((teacher) => (
                    <SelectItem key={teacher.id} value={teacher.id}>
                      {teacher.firstName} {teacher.lastName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              {...form.register("description")}
              data-testid="textarea-description"
            />
          </div>

          <div className="flex justify-end space-x-2 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              data-testid="button-cancel"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={mutation.isPending}
              data-testid="button-save"
            >
              {mutation.isPending
                ? "Saving..."
                : isEditing
                ? "Update Course"
                : "Add Course"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}