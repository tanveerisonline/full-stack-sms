import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  GraduationCap, 
  LayoutDashboard, 
  Users, 
  Presentation, 
  Book, 
  CalendarCheck, 
  TrendingUp, 
  DollarSign, 
  FileText, 
  LogOut 
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

const getAllNavItems = () => [
  { icon: LayoutDashboard, label: "Dashboard", href: "/", roles: ["admin", "teacher", "student", "parent"] },
  { icon: Users, label: "Students", href: "/students", roles: ["admin", "teacher"] },
  { icon: Presentation, label: "Teachers", href: "/teachers", roles: ["admin"] },
  { icon: Book, label: "Courses", href: "/courses", roles: ["admin", "teacher"] },
  { icon: CalendarCheck, label: "Attendance", href: "/attendance", roles: ["admin", "teacher"] },
  { icon: TrendingUp, label: "Grades", href: "/grades", roles: ["admin", "teacher"] },
  { icon: DollarSign, label: "Fees", href: "/fees", roles: ["admin"] },
  { icon: FileText, label: "Reports", href: "/reports", roles: ["admin", "teacher", "student", "parent"] },
];

export default function Sidebar({ isOpen, onClose }: SidebarProps) {
  const [location] = useLocation();
  const { role, user } = useAuth();
  
  // Filter navigation items based on user role
  const navItems = getAllNavItems().filter(item => 
    role && item.roles.includes(role)
  );

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  return (
    <div className={cn(
      "fixed inset-y-0 left-0 z-50 w-64 bg-white shadow-lg transform transition-transform duration-300 ease-in-out",
      isOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
    )}>
      <div className="flex items-center justify-center h-16 px-4 bg-blue-600">
        <div className="flex items-center space-x-2">
          <GraduationCap className="h-8 w-8 text-white" />
          <span className="text-xl font-bold text-white">EduManage</span>
        </div>
      </div>

      <nav className="mt-8 px-4">
        <div className="space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.href;
            
            return (
              <Link key={item.href} href={item.href}>
                <div
                  className={cn(
                    "flex items-center px-4 py-3 text-gray-700 rounded-lg hover:bg-blue-50 hover:text-blue-600 transition-colors cursor-pointer",
                    isActive && "bg-blue-50 text-blue-600"
                  )}
                  onClick={onClose}
                  data-testid={`nav-${item.label.toLowerCase()}`}
                >
                  <Icon className="h-5 w-5 mr-3" />
                  <span>{item.label}</span>
                </div>
              </Link>
            );
          })}
        </div>

        <div className="mt-8 pt-8 border-t border-gray-200">
          <button
            onClick={handleLogout}
            className="flex items-center w-full px-4 py-3 text-gray-700 rounded-lg hover:bg-red-50 hover:text-red-600 transition-colors"
            data-testid="button-logout"
          >
            <LogOut className="h-5 w-5 mr-3" />
            <span>Logout</span>
          </button>
        </div>
      </nav>
    </div>
  );
}
