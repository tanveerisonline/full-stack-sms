import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  FileText, 
  Download, 
  Eye, 
  Calendar, 
  Users, 
  TrendingUp, 
  DollarSign,
  CalendarCheck
} from "lucide-react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { type Grade, type Course } from "@shared/schema";

export default function Reports() {
  const [reportType, setReportType] = useState("");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [format, setFormat] = useState("pdf");
  const [gradeId, setGradeId] = useState("");
  const [courseId, setCourseId] = useState("");
  const [examType, setExamType] = useState("");
  const [feeType, setFeeType] = useState("");
  const [status, setStatus] = useState("");

  const { toast } = useToast();
  const { isAdmin, role } = useAuth();

  // Fetch grades and courses for dropdowns
  const { data: grades } = useQuery<Grade[]>({
    queryKey: ["/api/grades"],
  });

  const { data: courses } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
  });

  // Generate report mutation
  const generateReportMutation = useMutation({
    mutationFn: async (params: any) => {
      const response = await apiRequest("POST", "/api/reports/generate", params);
      return await response.json();
    },
    onSuccess: (data: any) => {
      toast({
        title: "Report Generated",
        description: `${data.message}. Records: ${data.recordCount}`,
      });
      
      // Download the generated file
      downloadFile(data.filename);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to generate report",
        variant: "destructive",
      });
    },
  });

  const downloadFile = (filename: string) => {
    const link = document.createElement('a');
    link.href = `/api/reports/download/${filename}`;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const reportCategories = [
    {
      title: "Student Reports",
      description: "Enrollment, performance, and demographic reports",
      icon: Users,
      color: "text-blue-600",
      bgColor: "bg-blue-100",
    },
    {
      title: "Attendance Reports", 
      description: "Daily, weekly, and monthly attendance analytics",
      icon: CalendarCheck,
      color: "text-green-600",
      bgColor: "bg-green-100",
    },
    {
      title: "Academic Reports",
      description: "Grades, assessments, and academic performance",
      icon: TrendingUp,
      color: "text-amber-600", 
      bgColor: "bg-amber-100",
    },
    {
      title: "Financial Reports",
      description: "Fee collection, payments, and financial analytics", 
      icon: DollarSign,
      color: "text-purple-600",
      bgColor: "bg-purple-100",
    },
  ];

  const recentReports = [
    {
      id: 1,
      name: "Monthly Attendance Report - December 2024",
      generatedAt: "December 31, 2024 at 2:30 PM",
      type: "PDF",
      size: "2.4 MB",
    },
    {
      id: 2,
      name: "Student Performance Report - Q4 2024", 
      generatedAt: "December 28, 2024 at 10:15 AM",
      type: "Excel",
      size: "1.8 MB",
    },
    {
      id: 3,
      name: "Fee Collection Summary - December 2024",
      generatedAt: "December 25, 2024 at 4:45 PM", 
      type: "PDF",
      size: "956 KB",
    },
    {
      id: 4,
      name: "Teacher Performance Analysis - 2024",
      generatedAt: "December 20, 2024 at 9:30 AM",
      type: "CSV", 
      size: "512 KB",
    },
  ];

  const handleGenerateReport = () => {
    if (!reportType) {
      toast({
        title: "Error",
        description: "Please select a report type",
        variant: "destructive",
      });
      return;
    }

    const reportTypeMapping: Record<string, string> = {
      "student-performance": "student",
      "attendance-summary": "attendance", 
      "fee-collection": "financial",
      "teacher-performance": "academic",
      "grade-analysis": "academic",
      "enrollment-trends": "student"
    };

    const mappedType = reportTypeMapping[reportType] || "student";

    generateReportMutation.mutate({
      reportType: mappedType,
      format,
      dateFrom: dateFrom || undefined,
      dateTo: dateTo || undefined,
      gradeId: gradeId || undefined,
      courseId: courseId || undefined,
      examType: examType || undefined,
      feeType: feeType || undefined,
      status: status || undefined,
    });
  };

  const handleQuickGenerate = (type: string) => {
    const typeMap: Record<string, string> = {
      "Student Reports": "student",
      "Attendance Reports": "attendance",
      "Academic Reports": "academic", 
      "Financial Reports": "financial"
    };
    
    const mappedType = typeMap[type];
    if (!mappedType) return;
    
    // Check permissions for financial reports
    if (mappedType === "financial" && !isAdmin) {
      toast({
        title: "Access Denied",
        description: "Only administrators can generate financial reports",
        variant: "destructive",
      });
      return;
    }

    generateReportMutation.mutate({
      reportType: mappedType,
      format: "pdf",
    });
  };

  const getFileIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case "pdf":
        return "fas fa-file-pdf text-red-600";
      case "excel":
        return "fas fa-file-excel text-green-600";
      case "csv":
        return "fas fa-file-csv text-blue-600";
      default:
        return "fas fa-file text-gray-600";
    }
  };

  const getFileColor = (type: string) => {
    switch (type.toLowerCase()) {
      case "pdf":
        return "bg-red-100";
      case "excel":
        return "bg-green-100";
      case "csv":
        return "bg-blue-100";
      default:
        return "bg-gray-100";
    }
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900" data-testid="text-reports-title">Reports & Analytics</h1>
        <p className="text-gray-600 mt-2">Generate comprehensive reports and analytics</p>
      </div>

      {/* Report Categories */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {reportCategories.map((category, index) => {
          const Icon = category.icon;
          return (
            <Card 
              key={index} 
              className="hover:shadow-md transition-shadow cursor-pointer"
              data-testid={`report-category-${index}`}
            >
              <CardContent className="p-6">
                <div className={`w-12 h-12 ${category.bgColor} rounded-lg flex items-center justify-center mb-4`}>
                  <Icon className={`${category.color} h-6 w-6`} />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{category.title}</h3>
                <p className="text-sm text-gray-600 mb-4">{category.description}</p>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => handleQuickGenerate(category.title)}
                  disabled={generateReportMutation.isPending}
                  className={`${category.color} hover:${category.color.replace('text-', 'bg-').replace('600', '50')}`}
                  data-testid={`button-generate-${index}`}
                >
                  {generateReportMutation.isPending ? "Generating..." : "Generate Report →"}
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Custom Report Builder */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Custom Report Builder</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Report Type</label>
              <Select value={reportType} onValueChange={setReportType}>
                <SelectTrigger data-testid="select-report-type">
                  <SelectValue placeholder="Select Report Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="student-performance">Student Performance</SelectItem>
                  <SelectItem value="attendance-summary">Attendance Summary</SelectItem>
                  <SelectItem value="fee-collection">Fee Collection</SelectItem>
                  <SelectItem value="teacher-performance">Teacher Performance</SelectItem>
                  <SelectItem value="grade-analysis">Grade Analysis</SelectItem>
                  <SelectItem value="enrollment-trends">Enrollment Trends</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Date Range</label>
              <div className="flex space-x-2">
                <Input
                  type="date"
                  value={dateFrom}
                  onChange={(e) => setDateFrom(e.target.value)}
                  placeholder="From"
                  data-testid="input-date-from"
                />
                <Input
                  type="date"
                  value={dateTo}
                  onChange={(e) => setDateTo(e.target.value)}
                  placeholder="To"
                  data-testid="input-date-to"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Format</label>
              <div className="flex space-x-2">
                <Select value={format} onValueChange={setFormat}>
                  <SelectTrigger data-testid="select-format">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pdf">PDF</SelectItem>
                    <SelectItem value="csv">CSV</SelectItem>
                  </SelectContent>
                </Select>
                <Button 
                  onClick={handleGenerateReport}
                  disabled={!reportType || generateReportMutation.isPending}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-6 disabled:opacity-50"
                  data-testid="button-generate-custom"
                >
                  {generateReportMutation.isPending ? "Generating..." : "Generate"}
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Recent Reports */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Reports</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="divide-y divide-gray-200">
            {recentReports.map((report) => (
              <div 
                key={report.id} 
                className="p-6 flex items-center justify-between hover:bg-gray-50 transition-colors"
                data-testid={`recent-report-${report.id}`}
              >
                <div className="flex items-center space-x-4">
                  <div className={`w-10 h-10 ${getFileColor(report.type)} rounded-lg flex items-center justify-center`}>
                    <FileText className="h-5 w-5 text-gray-600" />
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-900" data-testid={`report-name-${report.id}`}>
                      {report.name}
                    </h4>
                    <p className="text-sm text-gray-500" data-testid={`report-date-${report.id}`}>
                      Generated on {report.generatedAt}
                    </p>
                    <div className="flex items-center space-x-2 mt-1">
                      <Badge variant="secondary" data-testid={`report-type-${report.id}`}>
                        {report.type}
                      </Badge>
                      <span className="text-xs text-gray-500" data-testid={`report-size-${report.id}`}>
                        {report.size}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Button 
                    variant="outline" 
                    size="sm"
                    data-testid={`button-download-${report.id}`}
                  >
                    <Download className="h-4 w-4 mr-1" />
                    Download
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm"
                    data-testid={`button-view-${report.id}`}
                  >
                    <Eye className="h-4 w-4 mr-1" />
                    View
                  </Button>
                </div>
              </div>
            ))}
          </div>

          {recentReports.length === 0 && (
            <div className="text-center py-12">
              <FileText className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-600 mb-2">No Reports Generated</h3>
              <p className="text-gray-500">Generate your first report using the custom report builder above</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
