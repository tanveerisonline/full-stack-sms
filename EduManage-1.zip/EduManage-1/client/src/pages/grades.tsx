import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus, Search, Edit, Eye, TrendingUp } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import GradeModal from "@/components/modals/grade-modal";
import type { StudentGrade, Student, Course } from "@shared/schema";

export default function Grades() {
  const { toast } = useToast();
  const [selectedStudent, setSelectedStudent] = useState("");
  const [selectedCourse, setSelectedCourse] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [editingGrade, setEditingGrade] = useState<StudentGrade | null>(null);

  const { data: students } = useQuery<{ students: Student[] }>({
    queryKey: ["/api/students", { limit: 100 }],
    queryFn: async () => {
      const response = await fetch("/api/students?limit=100", {
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to fetch students");
      return response.json();
    },
  });

  const { data: courses } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
  });

  const { data: grades, isLoading } = useQuery<StudentGrade[]>({
    queryKey: ["/api/students", selectedStudent, "grades", { courseId: selectedCourse }],
    queryFn: async () => {
      if (!selectedStudent) return [];
      const params = new URLSearchParams({
        ...(selectedCourse && selectedCourse !== "all" && { courseId: selectedCourse }),
      });
      const response = await fetch(`/api/students/${selectedStudent}/grades?${params}`, {
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to fetch grades");
      return response.json();
    },
    enabled: !!selectedStudent,
  });

  const addGradeMutation = useMutation({
    mutationFn: async (data: {
      studentId: string;
      courseId: string;
      examType: string;
      marks: number;
      totalMarks: number;
      grade?: string;
      examDate?: string;
    }) => {
      await apiRequest("POST", "/api/grades", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/students", selectedStudent, "grades"] });
      toast({
        title: "Success",
        description: "Grade added successfully",
      });
      setShowModal(false);
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to add grade",
        variant: "destructive",
      });
    },
  });

  const handleEdit = (grade: StudentGrade) => {
    setEditingGrade(grade);
    setShowModal(true);
  };

  const handleModalClose = () => {
    setShowModal(false);
    setEditingGrade(null);
  };

  const getGradeLetter = (marks: number, totalMarks: number) => {
    const percentage = (marks / totalMarks) * 100;
    if (percentage >= 90) return "A+";
    if (percentage >= 80) return "A";
    if (percentage >= 70) return "B+";
    if (percentage >= 60) return "B";
    if (percentage >= 50) return "C";
    return "F";
  };

  const getGradeColor = (grade: string) => {
    const colors = {
      "A+": "bg-green-100 text-green-800",
      "A": "bg-green-100 text-green-700",
      "B+": "bg-blue-100 text-blue-800",
      "B": "bg-blue-100 text-blue-700",
      "C": "bg-yellow-100 text-yellow-800",
      "F": "bg-red-100 text-red-800",
    };
    return colors[grade as keyof typeof colors] || "bg-gray-100 text-gray-800";
  };

  const getCourseName = (courseId: string) => {
    return courses?.find(c => c.id === courseId)?.name || "Unknown Course";
  };

  const getStudentName = (studentId: string) => {
    const student = students?.students.find(s => s.id === studentId);
    return student ? `${student.firstName} ${student.lastName}` : "Unknown Student";
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900" data-testid="text-grades-title">Grade Management</h1>
          <p className="text-gray-600 mt-2">Manage student grades and digital report cards</p>
        </div>
        <Button
          onClick={() => setShowModal(true)}
          disabled={!selectedStudent}
          className="bg-blue-600 hover:bg-blue-700 text-white flex items-center space-x-2 disabled:opacity-50"
          data-testid="button-add-grade"
        >
          <Plus className="h-4 w-4" />
          <span>Add Grade</span>
        </Button>
      </div>

      {/* Student and Course Selection */}
      <Card className="mb-8">
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Select Student</label>
              <Select value={selectedStudent} onValueChange={setSelectedStudent}>
                <SelectTrigger data-testid="select-student">
                  <SelectValue placeholder="Choose a student" />
                </SelectTrigger>
                <SelectContent>
                  {students?.students.map((student) => (
                    <SelectItem key={student.id} value={student.id}>
                      {student.firstName} {student.lastName} ({student.studentId})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Filter by Course</label>
              <Select value={selectedCourse} onValueChange={setSelectedCourse}>
                <SelectTrigger data-testid="select-course-filter">
                  <SelectValue placeholder="All Courses" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Courses</SelectItem>
                  {courses?.map((course) => (
                    <SelectItem key={course.id} value={course.id}>
                      {course.name} ({course.code})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end">
              <Button
                variant="outline"
                className="w-full"
                onClick={() => {
                  setSelectedStudent("");
                  setSelectedCourse("all");
                }}
                data-testid="button-clear-selection"
              >
                Clear Selection
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Grades Content */}
      {!selectedStudent ? (
        <Card>
          <CardContent className="p-12">
            <div className="text-center">
              <TrendingUp className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-600 mb-2">Select a Student</h3>
              <p className="text-gray-500">Choose a student to view and manage their grades</p>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle data-testid="text-grades-table-title">
              Grades for {getStudentName(selectedStudent)}
              {selectedCourse && ` - ${getCourseName(selectedCourse)}`}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-4">
                {Array.from({ length: 5 }).map((_, index) => (
                  <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex-1 space-y-2">
                      <Skeleton className="h-4 w-32" />
                      <Skeleton className="h-3 w-24" />
                    </div>
                    <div className="flex items-center space-x-4">
                      <Skeleton className="h-4 w-16" />
                      <Skeleton className="h-6 w-12 rounded-full" />
                      <Skeleton className="h-8 w-16" />
                    </div>
                  </div>
                ))}
              </div>
            ) : grades?.length === 0 ? (
              <div className="text-center py-12">
                <TrendingUp className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-600 mb-2">No Grades Found</h3>
                <p className="text-gray-500">No grades have been recorded for this student yet</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Course
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Exam Type
                      </th>
                      <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Marks
                      </th>
                      <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Grade
                      </th>
                      <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Date
                      </th>
                      <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {grades?.map((grade) => {
                      const gradeLetter = grade.grade || getGradeLetter(Number(grade.marks), Number(grade.totalMarks));
                      return (
                        <tr key={grade.id} className="hover:bg-gray-50" data-testid={`grade-row-${grade.id}`}>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm font-medium text-gray-900" data-testid={`grade-course-${grade.id}`}>
                              {getCourseName(grade.courseId)}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-900 capitalize" data-testid={`grade-exam-type-${grade.id}`}>
                              {grade.examType}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-center">
                            <div className="text-sm font-medium text-gray-900" data-testid={`grade-marks-${grade.id}`}>
                              {grade.marks}/{grade.totalMarks}
                            </div>
                            <div className="text-xs text-gray-500">
                              {Math.round((Number(grade.marks) / Number(grade.totalMarks)) * 100)}%
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-center">
                            <Badge className={getGradeColor(gradeLetter)} data-testid={`grade-letter-${grade.id}`}>
                              {gradeLetter}
                            </Badge>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-900" data-testid={`grade-date-${grade.id}`}>
                            {grade.examDate ? new Date(grade.examDate).toLocaleDateString() : "N/A"}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                            <div className="flex items-center justify-end space-x-2">
                              <Button
                                variant="ghost"
                                size="sm"
                                data-testid={`button-view-${grade.id}`}
                              >
                                <Eye className="h-4 w-4 text-blue-600" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleEdit(grade)}
                                data-testid={`button-edit-${grade.id}`}
                              >
                                <Edit className="h-4 w-4 text-gray-600" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      <GradeModal
        isOpen={showModal}
        onClose={handleModalClose}
        grade={editingGrade}
        studentId={selectedStudent}
        courses={courses || []}
      />
    </div>
  );
}
