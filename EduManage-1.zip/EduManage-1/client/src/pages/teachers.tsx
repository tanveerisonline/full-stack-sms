import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus, Search, Eye, Edit, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import TeacherModal from "@/components/modals/teacher-modal";
import type { Teacher } from "@shared/schema";

export default function Teachers() {
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [subjectFilter, setSubjectFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [editingTeacher, setEditingTeacher] = useState<Teacher | null>(null);

  const { data: teachers, isLoading } = useQuery<Teacher[]>({
    queryKey: ["/api/teachers", { search, subjectFilter, statusFilter }],
    queryFn: async () => {
      const params = new URLSearchParams({
        ...(search && { search }),
        ...(subjectFilter && subjectFilter !== "all" && { subject: subjectFilter }),
        ...(statusFilter && statusFilter !== "all" && { status: statusFilter }),
      });
      const response = await fetch(`/api/teachers?${params}`, {
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to fetch teachers");
      return response.json();
    },
  });

  const deleteTeacherMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/teachers/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/teachers"] });
      toast({
        title: "Success",
        description: "Teacher deleted successfully",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to delete teacher",
        variant: "destructive",
      });
    },
  });

  const handleEdit = (teacher: Teacher) => {
    setEditingTeacher(teacher);
    setShowModal(true);
  };

  const handleDelete = async (id: string) => {
    if (confirm("Are you sure you want to delete this teacher?")) {
      deleteTeacherMutation.mutate(id);
    }
  };

  const handleModalClose = () => {
    setShowModal(false);
    setEditingTeacher(null);
  };

  const getStatusBadge = (status: string) => {
    const variants = {
      active: "bg-green-100 text-green-800",
      inactive: "bg-red-100 text-red-800",
    };
    return variants[status as keyof typeof variants] || "bg-gray-100 text-gray-800";
  };

  const getInitials = (firstName: string, lastName: string) => {
    return `${firstName?.[0] || ''}${lastName?.[0] || ''}`.toUpperCase();
  };

  const getBgColor = (index: number) => {
    const colors = ["bg-blue-100", "bg-green-100", "bg-purple-100", "bg-amber-100", "bg-pink-100", "bg-indigo-100"];
    return colors[index % colors.length];
  };

  const getTextColor = (index: number) => {
    const colors = ["text-blue-600", "text-green-600", "text-purple-600", "text-amber-600", "text-pink-600", "text-indigo-600"];
    return colors[index % colors.length];
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900" data-testid="text-teachers-title">Teachers</h1>
          <p className="text-gray-600 mt-2">Manage teaching staff and their assignments</p>
        </div>
        <Button
          onClick={() => setShowModal(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white flex items-center space-x-2"
          data-testid="button-add-teacher"
        >
          <Plus className="h-4 w-4" />
          <span>Add New Teacher</span>
        </Button>
      </div>

      {/* Filter and Search */}
      <Card className="mb-8">
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Search</label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  type="text"
                  placeholder="Search teachers..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-10"
                  data-testid="input-search-teachers"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Subject</label>
              <Select value={subjectFilter} onValueChange={setSubjectFilter}>
                <SelectTrigger data-testid="select-subject-filter">
                  <SelectValue placeholder="All Subjects" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Subjects</SelectItem>
                  <SelectItem value="Mathematics">Mathematics</SelectItem>
                  <SelectItem value="Science">Science</SelectItem>
                  <SelectItem value="English">English</SelectItem>
                  <SelectItem value="History">History</SelectItem>
                  <SelectItem value="Geography">Geography</SelectItem>
                  <SelectItem value="Physics">Physics</SelectItem>
                  <SelectItem value="Chemistry">Chemistry</SelectItem>
                  <SelectItem value="Biology">Biology</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Status</label>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger data-testid="select-status-filter">
                  <SelectValue placeholder="All Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end">
              <Button
                variant="outline"
                className="w-full"
                onClick={() => {
                  setSearch("");
                  setSubjectFilter("all");
                  setStatusFilter("all");
                }}
                data-testid="button-clear-filters"
              >
                Clear Filters
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Teachers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {isLoading ? (
          Array.from({ length: 6 }).map((_, index) => (
            <Card key={index}>
              <CardContent className="p-6">
                <div className="text-center mb-4">
                  <Skeleton className="w-16 h-16 rounded-full mx-auto mb-3" />
                  <Skeleton className="h-6 w-32 mx-auto mb-2" />
                  <Skeleton className="h-4 w-24 mx-auto" />
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Skeleton className="h-4 w-20" />
                    <Skeleton className="h-4 w-16" />
                  </div>
                  <div className="flex justify-between">
                    <Skeleton className="h-4 w-16" />
                    <Skeleton className="h-4 w-12" />
                  </div>
                  <div className="flex justify-between">
                    <Skeleton className="h-4 w-20" />
                    <Skeleton className="h-4 w-16" />
                  </div>
                </div>
                <div className="mt-4 flex space-x-2">
                  <Skeleton className="h-8 flex-1" />
                  <Skeleton className="h-8 flex-1" />
                </div>
              </CardContent>
            </Card>
          ))
        ) : teachers?.length === 0 ? (
          <div className="col-span-full text-center py-12">
            <p className="text-gray-500">No teachers found. Add your first teacher to get started.</p>
          </div>
        ) : (
          teachers?.map((teacher, index) => (
            <Card key={teacher.id} data-testid={`teacher-card-${teacher.id}`}>
              <CardContent className="p-6">
                <div className="text-center mb-4">
                  <div className={`w-16 h-16 ${getBgColor(index)} rounded-full mx-auto flex items-center justify-center mb-3`}>
                    <span className={`${getTextColor(index)} font-bold text-xl`}>
                      {getInitials(teacher.firstName || "", teacher.lastName || "")}
                    </span>
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900" data-testid={`teacher-name-${teacher.id}`}>
                    {teacher.firstName} {teacher.lastName}
                  </h3>
                  <p className="text-gray-600" data-testid={`teacher-subject-${teacher.id}`}>
                    {teacher.subject || "No Subject Assigned"}
                  </p>
                </div>
                
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Employee ID:</span>
                    <span className="font-medium" data-testid={`teacher-employee-id-${teacher.id}`}>
                      {teacher.employeeId}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Experience:</span>
                    <span className="font-medium" data-testid={`teacher-experience-${teacher.id}`}>
                      {teacher.experience ? `${teacher.experience} years` : "N/A"}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Status:</span>
                    <Badge className={getStatusBadge(teacher.status || "active")} data-testid={`teacher-status-${teacher.id}`}>
                      {teacher.status || "active"}
                    </Badge>
                  </div>
                </div>
                
                <div className="mt-4 flex space-x-2">
                  <Button
                    variant="outline"
                    className="flex-1 bg-blue-50 text-blue-600 hover:bg-blue-100"
                    data-testid={`button-view-${teacher.id}`}
                  >
                    <Eye className="h-4 w-4 mr-1" />
                    View Profile
                  </Button>
                  <Button
                    variant="outline"
                    className="flex-1 bg-gray-50 text-gray-600 hover:bg-gray-100"
                    onClick={() => handleEdit(teacher)}
                    data-testid={`button-edit-${teacher.id}`}
                  >
                    <Edit className="h-4 w-4 mr-1" />
                    Edit
                  </Button>
                </div>
                
                <Button
                  variant="outline"
                  className="w-full mt-2 text-red-600 hover:bg-red-50"
                  onClick={() => handleDelete(teacher.id)}
                  data-testid={`button-delete-${teacher.id}`}
                >
                  <Trash2 className="h-4 w-4 mr-1" />
                  Delete
                </Button>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      <TeacherModal
        isOpen={showModal}
        onClose={handleModalClose}
        teacher={editingTeacher}
      />
    </div>
  );
}
