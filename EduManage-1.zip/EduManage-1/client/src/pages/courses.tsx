import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus, Search, Edit, Trash2, Book, User } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import CourseModal from "@/components/modals/course-modal";
import type { Course, Grade, Teacher } from "@shared/schema";

export default function Courses() {
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [gradeFilter, setGradeFilter] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [editingCourse, setEditingCourse] = useState<Course | null>(null);

  const { data: courses, isLoading } = useQuery<Course[]>({
    queryKey: ["/api/courses", { gradeId: gradeFilter }],
    queryFn: async () => {
      const params = new URLSearchParams({
        ...(gradeFilter && gradeFilter !== "all" && { gradeId: gradeFilter }),
      });
      const response = await fetch(`/api/courses?${params}`, {
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to fetch courses");
      return response.json();
    },
  });

  const { data: grades } = useQuery<Grade[]>({
    queryKey: ["/api/grades"],
  });

  const { data: teachers } = useQuery<Teacher[]>({
    queryKey: ["/api/teachers"],
  });

  const deleteCourseMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/courses/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/courses"] });
      toast({
        title: "Success",
        description: "Course deleted successfully",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to delete course",
        variant: "destructive",
      });
    },
  });

  const handleEdit = (course: Course) => {
    setEditingCourse(course);
    setShowModal(true);
  };

  const handleDelete = async (id: string) => {
    if (confirm("Are you sure you want to delete this course?")) {
      deleteCourseMutation.mutate(id);
    }
  };

  const handleModalClose = () => {
    setShowModal(false);
    setEditingCourse(null);
  };

  const getGradeName = (gradeId: string | null) => {
    if (!gradeId) return "N/A";
    const grade = grades?.find(g => g.id === gradeId);
    return grade ? `${grade.name} ${grade.section ? `- Section ${grade.section}` : ''}` : "N/A";
  };

  const getTeacherName = (teacherId: string | null) => {
    if (!teacherId) return "Not Assigned";
    const teacher = teachers?.find(t => t.id === teacherId);
    return teacher ? `${teacher.firstName} ${teacher.lastName}` : "Not Assigned";
  };

  const filteredCourses = courses?.filter(course =>
    course.name.toLowerCase().includes(search.toLowerCase()) ||
    course.code.toLowerCase().includes(search.toLowerCase())
  );

  const getBgColor = (index: number) => {
    const colors = ["bg-blue-100", "bg-green-100", "bg-purple-100", "bg-amber-100", "bg-pink-100", "bg-indigo-100"];
    return colors[index % colors.length];
  };

  const getTextColor = (index: number) => {
    const colors = ["text-blue-600", "text-green-600", "text-purple-600", "text-amber-600", "text-pink-600", "text-indigo-600"];
    return colors[index % colors.length];
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900" data-testid="text-courses-title">Courses</h1>
          <p className="text-gray-600 mt-2">Manage courses and class schedules</p>
        </div>
        <Button
          onClick={() => setShowModal(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white flex items-center space-x-2"
          data-testid="button-add-course"
        >
          <Plus className="h-4 w-4" />
          <span>Add New Course</span>
        </Button>
      </div>

      {/* Filter and Search */}
      <Card className="mb-8">
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Search</label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  type="text"
                  placeholder="Search courses..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-10"
                  data-testid="input-search-courses"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Grade</label>
              <Select value={gradeFilter} onValueChange={setGradeFilter}>
                <SelectTrigger data-testid="select-grade-filter">
                  <SelectValue placeholder="All Grades" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Grades</SelectItem>
                  {grades?.map((grade) => (
                    <SelectItem key={grade.id} value={grade.id}>
                      {grade.name} {grade.section && `- Section ${grade.section}`}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end">
              <Button
                variant="outline"
                className="w-full"
                onClick={() => {
                  setSearch("");
                  setGradeFilter("all");
                }}
                data-testid="button-clear-filters"
              >
                Clear Filters
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Courses Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {isLoading ? (
          Array.from({ length: 6 }).map((_, index) => (
            <Card key={index}>
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <Skeleton className="w-12 h-12 rounded-lg" />
                  <div className="ml-4 flex-1">
                    <Skeleton className="h-6 w-32 mb-2" />
                    <Skeleton className="h-4 w-24" />
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Skeleton className="h-4 w-20" />
                    <Skeleton className="h-4 w-16" />
                  </div>
                  <div className="flex justify-between">
                    <Skeleton className="h-4 w-16" />
                    <Skeleton className="h-4 w-24" />
                  </div>
                </div>
                <div className="mt-4 flex space-x-2">
                  <Skeleton className="h-8 flex-1" />
                  <Skeleton className="h-8 flex-1" />
                </div>
              </CardContent>
            </Card>
          ))
        ) : filteredCourses?.length === 0 ? (
          <div className="col-span-full text-center py-12">
            <Book className="h-16 w-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-600 mb-2">No Courses Found</h3>
            <p className="text-gray-500">Add your first course to get started</p>
          </div>
        ) : (
          filteredCourses?.map((course, index) => (
            <Card key={course.id} data-testid={`course-card-${course.id}`}>
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <div className={`w-12 h-12 ${getBgColor(index)} rounded-lg flex items-center justify-center`}>
                    <Book className={`${getTextColor(index)} h-6 w-6`} />
                  </div>
                  <div className="ml-4 flex-1">
                    <h3 className="text-lg font-semibold text-gray-900" data-testid={`course-name-${course.id}`}>
                      {course.name}
                    </h3>
                    <p className="text-sm text-gray-600" data-testid={`course-code-${course.id}`}>
                      {course.code}
                    </p>
                  </div>
                </div>

                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Credits:</span>
                    <Badge variant="secondary" data-testid={`course-credits-${course.id}`}>
                      {course.credits || 1}
                    </Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Grade:</span>
                    <span className="font-medium" data-testid={`course-grade-${course.id}`}>
                      {getGradeName(course.gradeId)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Teacher:</span>
                    <span className="font-medium text-right" data-testid={`course-teacher-${course.id}`}>
                      {getTeacherName(course.teacherId)}
                    </span>
                  </div>
                </div>

                {course.description && (
                  <div className="mt-3">
                    <p className="text-sm text-gray-600 line-clamp-2" data-testid={`course-description-${course.id}`}>
                      {course.description}
                    </p>
                  </div>
                )}

                <div className="mt-4 flex space-x-2">
                  <Button
                    variant="outline"
                    className="flex-1 bg-blue-50 text-blue-600 hover:bg-blue-100"
                    onClick={() => handleEdit(course)}
                    data-testid={`button-edit-${course.id}`}
                  >
                    <Edit className="h-4 w-4 mr-1" />
                    Edit
                  </Button>
                  <Button
                    variant="outline"
                    className="flex-1 bg-red-50 text-red-600 hover:bg-red-100"
                    onClick={() => handleDelete(course.id)}
                    data-testid={`button-delete-${course.id}`}
                  >
                    <Trash2 className="h-4 w-4 mr-1" />
                    Delete
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      <CourseModal
        isOpen={showModal}
        onClose={handleModalClose}
        course={editingCourse}
      />
    </div>
  );
}
