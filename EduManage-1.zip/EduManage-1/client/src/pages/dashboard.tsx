import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Users, 
  Presentation, 
  CalendarCheck, 
  DollarSign,
  UserPlus,
  Book,
  FileText,
  Plus
} from "lucide-react";
import { Link } from "wouter";

interface DashboardMetrics {
  totalStudents: number;
  totalTeachers: number;
  todayAttendance: number;
  monthlyRevenue: number;
}

export default function Dashboard() {
  const { data: metrics, isLoading } = useQuery<DashboardMetrics>({
    queryKey: ["/api/dashboard/metrics"],
  });

  const metricCards = [
    {
      title: "Total Students",
      value: metrics?.totalStudents || 0,
      icon: Users,
      color: "text-blue-600",
      bgColor: "bg-blue-100",
    },
    {
      title: "Teachers",
      value: metrics?.totalTeachers || 0,
      icon: Presentation,
      color: "text-green-600",
      bgColor: "bg-green-100",
    },
    {
      title: "Today's Attendance",
      value: `${metrics?.todayAttendance || 0}%`,
      icon: CalendarCheck,
      color: "text-amber-600",
      bgColor: "bg-amber-100",
    },
    {
      title: "Revenue This Month",
      value: `$${metrics?.monthlyRevenue?.toLocaleString() || '0'}`,
      icon: DollarSign,
      color: "text-purple-600",
      bgColor: "bg-purple-100",
    },
  ];

  const quickActions = [
    { icon: UserPlus, label: "Add Student", href: "/students", color: "border-blue-300 hover:bg-blue-50" },
    { icon: Presentation, label: "Add Teacher", href: "/teachers", color: "border-green-300 hover:bg-green-50" },
    { icon: Book, label: "Create Course", href: "/courses", color: "border-purple-300 hover:bg-purple-50" },
    { icon: FileText, label: "Generate Report", href: "/reports", color: "border-amber-300 hover:bg-amber-50" },
  ];

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900" data-testid="text-dashboard-title">Dashboard</h1>
        <p className="text-gray-600 mt-2">Welcome back! Here's what's happening at your school.</p>
      </div>

      {/* Key Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {metricCards.map((metric, index) => {
          const Icon = metric.icon;
          return (
            <Card key={index} className="border border-gray-100">
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className={`w-12 h-12 ${metric.bgColor} rounded-lg flex items-center justify-center`}>
                      <Icon className={`${metric.color} h-6 w-6`} />
                    </div>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">{metric.title}</p>
                    {isLoading ? (
                      <Skeleton className="h-8 w-16 mt-1" />
                    ) : (
                      <p className="text-3xl font-bold text-gray-900" data-testid={`metric-${metric.title.toLowerCase().replace(/[^a-z0-9]/g, '-')}`}>
                        {metric.value}
                      </p>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Charts and Recent Activities */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        <Card>
          <CardHeader>
            <CardTitle>Monthly Enrollment</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 flex items-center justify-center text-gray-500">
              Chart visualization will be implemented here
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Activities</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center space-x-3 p-3 rounded-lg border border-gray-100">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                  <UserPlus className="h-4 w-4 text-blue-600" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900">System initialized successfully</p>
                  <p className="text-xs text-gray-500">Ready for student enrollment</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {quickActions.map((action, index) => {
              const Icon = action.icon;
              return (
                <Link key={index} href={action.href}>
                  <Button
                    variant="outline"
                    className={`h-auto flex flex-col items-center p-4 border-2 border-dashed ${action.color} transition-colors`}
                    data-testid={`quick-action-${action.label.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    <Icon className="h-6 w-6 text-gray-400 mb-2" />
                    <span className="text-sm font-medium text-gray-700">{action.label}</span>
                  </Button>
                </Link>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
