import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Check, X, Clock, Search, Calendar } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import type { Attendance, Grade, Student } from "@shared/schema";

interface AttendanceStats {
  present: number;
  absent: number;
  late: number;
  rate: number;
}

export default function AttendancePage() {
  const { toast } = useToast();
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [selectedGrade, setSelectedGrade] = useState("");

  const { data: stats, isLoading: statsLoading } = useQuery<AttendanceStats>({
    queryKey: ["/api/attendance/stats", { date: selectedDate }],
    queryFn: async () => {
      const response = await fetch(`/api/attendance/stats?date=${selectedDate}`, {
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to fetch attendance stats");
      return response.json();
    },
  });

  const { data: attendance, isLoading: attendanceLoading } = useQuery<Attendance[]>({
    queryKey: ["/api/attendance", { date: selectedDate, gradeId: selectedGrade }],
    queryFn: async () => {
      const params = new URLSearchParams({
        date: selectedDate,
        ...(selectedGrade && selectedGrade !== "all" && { gradeId: selectedGrade }),
      });
      const response = await fetch(`/api/attendance?${params}`, {
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to fetch attendance");
      return response.json();
    },
  });

  const { data: grades } = useQuery<Grade[]>({
    queryKey: ["/api/grades"],
  });

  const { data: students } = useQuery<Student[]>({
    queryKey: ["/api/students", { gradeId: selectedGrade }],
    queryFn: async () => {
      const params = new URLSearchParams({
        ...(selectedGrade && selectedGrade !== "all" && { gradeId: selectedGrade }),
        limit: "100",
      });
      const response = await fetch(`/api/students?${params}`, {
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to fetch students");
      const data = await response.json();
      return data.students;
    },
    enabled: !!selectedGrade,
  });

  const markAttendanceMutation = useMutation({
    mutationFn: async (data: { studentId: string; status: string; timeIn?: string }) => {
      await apiRequest("POST", "/api/attendance", {
        studentId: data.studentId,
        date: selectedDate,
        status: data.status,
        timeIn: data.timeIn,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/attendance"] });
      queryClient.invalidateQueries({ queryKey: ["/api/attendance/stats"] });
      toast({
        title: "Success",
        description: "Attendance marked successfully",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to mark attendance",
        variant: "destructive",
      });
    },
  });

  const handleMarkAttendance = (studentId: string, status: string) => {
    const timeIn = status === 'present' || status === 'late' ? new Date().toLocaleTimeString('en-US', { 
      hour12: false, 
      hour: '2-digit', 
      minute: '2-digit' 
    }) : undefined;
    
    markAttendanceMutation.mutate({ studentId, status, timeIn });
  };

  const getStatusBadge = (status: string) => {
    const variants = {
      present: "bg-green-100 text-green-800",
      absent: "bg-red-100 text-red-800",
      late: "bg-yellow-100 text-yellow-800",
    };
    return variants[status as keyof typeof variants] || "bg-gray-100 text-gray-800";
  };

  const getAttendanceForStudent = (studentId: string) => {
    return attendance?.find(a => a.studentId === studentId);
  };

  const statCards = [
    {
      title: "Present",
      value: stats?.present || 0,
      icon: Check,
      color: "text-green-600",
      bgColor: "bg-green-100",
    },
    {
      title: "Absent",
      value: stats?.absent || 0,
      icon: X,
      color: "text-red-600",
      bgColor: "bg-red-100",
    },
    {
      title: "Late",
      value: stats?.late || 0,
      icon: Clock,
      color: "text-yellow-600",
      bgColor: "bg-yellow-100",
    },
    {
      title: "Attendance Rate",
      value: `${stats?.rate || 0}%`,
      icon: Calendar,
      color: "text-blue-600",
      bgColor: "bg-blue-100",
    },
  ];

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900" data-testid="text-attendance-title">Attendance Management</h1>
        <p className="text-gray-600 mt-2">Track and manage student attendance</p>
      </div>

      {/* Date and Grade Selection */}
      <Card className="mb-8">
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Select Date</label>
              <Input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                data-testid="input-attendance-date"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Select Class</label>
              <Select value={selectedGrade} onValueChange={setSelectedGrade}>
                <SelectTrigger data-testid="select-attendance-grade">
                  <SelectValue placeholder="All Classes" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Classes</SelectItem>
                  {grades?.map((grade) => (
                    <SelectItem key={grade.id} value={grade.id}>
                      {grade.name} {grade.section && `- Section ${grade.section}`}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end">
              <Button
                onClick={() => {
                  queryClient.invalidateQueries({ queryKey: ["/api/attendance"] });
                  queryClient.invalidateQueries({ queryKey: ["/api/attendance/stats"] });
                }}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                data-testid="button-load-attendance"
              >
                <Search className="h-4 w-4 mr-2" />
                Load Attendance
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Attendance Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        {statCards.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index}>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className={`w-12 h-12 ${stat.bgColor} rounded-lg flex items-center justify-center`}>
                    <Icon className={`${stat.color} h-6 w-6`} />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                    {statsLoading ? (
                      <Skeleton className="h-8 w-16 mt-1" />
                    ) : (
                      <p className="text-2xl font-bold text-gray-900" data-testid={`stat-${stat.title.toLowerCase().replace(/\s+/g, '-')}`}>
                        {stat.value}
                      </p>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Attendance Table */}
      <Card>
        <CardHeader>
          <CardTitle data-testid="text-attendance-table-title">
            {selectedGrade 
              ? `${grades?.find(g => g.id === selectedGrade)?.name || 'Selected Class'} - ${selectedDate}` 
              : `All Classes - ${selectedDate}`
            }
          </CardTitle>
        </CardHeader>
        <CardContent>
          {!selectedGrade ? (
            <div className="text-center py-12">
              <Calendar className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-600 mb-2">Select a Class</h3>
              <p className="text-gray-500">Please select a class to view and manage attendance</p>
            </div>
          ) : attendanceLoading ? (
            <div className="space-y-4">
              {Array.from({ length: 5 }).map((_, index) => (
                <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    <Skeleton className="w-8 h-8 rounded-full" />
                    <Skeleton className="h-4 w-32" />
                  </div>
                  <div className="flex space-x-2">
                    <Skeleton className="h-8 w-20" />
                    <Skeleton className="h-8 w-20" />
                    <Skeleton className="h-8 w-20" />
                  </div>
                </div>
              ))}
            </div>
          ) : students?.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-500">No students found in the selected class</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Student
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Roll No.
                    </th>
                    <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                    <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Time In
                    </th>
                    <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {students?.map((student, index) => {
                    const studentAttendance = getAttendanceForStudent(student.id);
                    return (
                      <tr key={student.id} data-testid={`attendance-row-${student.id}`}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                              <span className="text-blue-600 font-medium text-xs">
                                {student.firstName?.[0]}{student.lastName?.[0]}
                              </span>
                            </div>
                            <div className="ml-3">
                              <div className="text-sm font-medium text-gray-900" data-testid={`student-name-${student.id}`}>
                                {student.firstName} {student.lastName}
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900" data-testid={`student-roll-${student.id}`}>
                          {index + 1}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-center">
                          {studentAttendance ? (
                            <Badge className={getStatusBadge(studentAttendance.status)} data-testid={`attendance-status-${student.id}`}>
                              {studentAttendance.status}
                            </Badge>
                          ) : (
                            <span className="text-gray-400 text-sm">Not marked</span>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-900" data-testid={`attendance-time-${student.id}`}>
                          {studentAttendance?.timeIn || "--"}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-center">
                          <div className="flex items-center justify-center space-x-2">
                            <Button
                              size="sm"
                              variant="outline"
                              className="bg-green-50 text-green-600 hover:bg-green-100 border-green-200"
                              onClick={() => handleMarkAttendance(student.id, 'present')}
                              disabled={markAttendanceMutation.isPending}
                              data-testid={`button-present-${student.id}`}
                            >
                              <Check className="h-3 w-3 mr-1" />
                              Present
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              className="bg-red-50 text-red-600 hover:bg-red-100 border-red-200"
                              onClick={() => handleMarkAttendance(student.id, 'absent')}
                              disabled={markAttendanceMutation.isPending}
                              data-testid={`button-absent-${student.id}`}
                            >
                              <X className="h-3 w-3 mr-1" />
                              Absent
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              className="bg-yellow-50 text-yellow-600 hover:bg-yellow-100 border-yellow-200"
                              onClick={() => handleMarkAttendance(student.id, 'late')}
                              disabled={markAttendanceMutation.isPending}
                              data-testid={`button-late-${student.id}`}
                            >
                              <Clock className="h-3 w-3 mr-1" />
                              Late
                            </Button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
