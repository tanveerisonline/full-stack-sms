import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Search, DollarSign, Receipt, CreditCard } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import FeeStructureModal from "@/components/modals/fee-structure-modal";
import FeePaymentModal from "@/components/modals/fee-payment-modal";
import type { FeeStructure, FeePayment, Grade, Student } from "@shared/schema";

export default function Fees() {
  const { toast } = useToast();
  const [selectedGrade, setSelectedGrade] = useState("");
  const [selectedStudent, setSelectedStudent] = useState("");
  const [showStructureModal, setShowStructureModal] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);

  const { data: grades } = useQuery<Grade[]>({
    queryKey: ["/api/grades"],
  });

  const { data: students } = useQuery<{ students: Student[] }>({
    queryKey: ["/api/students", { limit: 100 }],
    queryFn: async () => {
      const response = await fetch("/api/students?limit=100", {
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to fetch students");
      return response.json();
    },
  });

  const { data: feeStructure, isLoading: structureLoading } = useQuery<FeeStructure[]>({
    queryKey: ["/api/fee-structure", { gradeId: selectedGrade }],
    queryFn: async () => {
      const params = new URLSearchParams({
        ...(selectedGrade && selectedGrade !== "all" && { gradeId: selectedGrade }),
      });
      const response = await fetch(`/api/fee-structure?${params}`, {
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to fetch fee structure");
      return response.json();
    },
  });

  const { data: feePayments, isLoading: paymentsLoading } = useQuery<FeePayment[]>({
    queryKey: ["/api/fee-payments", { studentId: selectedStudent }],
    queryFn: async () => {
      const params = new URLSearchParams({
        ...(selectedStudent && selectedStudent !== "all" && { studentId: selectedStudent }),
      });
      const response = await fetch(`/api/fee-payments?${params}`, {
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to fetch fee payments");
      return response.json();
    },
  });

  const getGradeName = (gradeId: string | null) => {
    if (!gradeId) return "N/A";
    const grade = grades?.find(g => g.id === gradeId);
    return grade ? `${grade.name} ${grade.section ? `- Section ${grade.section}` : ''}` : "N/A";
  };

  const getStudentName = (studentId: string | null) => {
    if (!studentId) return "N/A";
    const student = students?.students.find(s => s.id === studentId);
    return student ? `${student.firstName} ${student.lastName}` : "N/A";
  };

  const getStatusBadge = (status: string) => {
    const variants = {
      paid: "bg-green-100 text-green-800",
      pending: "bg-yellow-100 text-yellow-800",
      overdue: "bg-red-100 text-red-800",
    };
    return variants[status as keyof typeof variants] || "bg-gray-100 text-gray-800";
  };

  const getFeeTypeColor = (index: number) => {
    const colors = ["bg-blue-100 text-blue-800", "bg-green-100 text-green-800", "bg-purple-100 text-purple-800", "bg-amber-100 text-amber-800"];
    return colors[index % colors.length];
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900" data-testid="text-fees-title">Fee Management</h1>
        <p className="text-gray-600 mt-2">Manage fee structure and payment tracking</p>
      </div>

      <Tabs defaultValue="structure" className="space-y-6">
        <TabsList className="grid w-full lg:w-96 grid-cols-2">
          <TabsTrigger value="structure" data-testid="tab-fee-structure">Fee Structure</TabsTrigger>
          <TabsTrigger value="payments" data-testid="tab-fee-payments">Payments</TabsTrigger>
        </TabsList>

        <TabsContent value="structure" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold text-gray-900">Fee Structure Management</h2>
            <Button
              onClick={() => setShowStructureModal(true)}
              className="bg-blue-600 hover:bg-blue-700 text-white flex items-center space-x-2"
              data-testid="button-add-fee-structure"
            >
              <Plus className="h-4 w-4" />
              <span>Add Fee Structure</span>
            </Button>
          </div>

          {/* Grade Filter */}
          <Card>
            <CardContent className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Select Grade</label>
                  <Select value={selectedGrade} onValueChange={setSelectedGrade}>
                    <SelectTrigger data-testid="select-grade-structure">
                      <SelectValue placeholder="All Grades" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Grades</SelectItem>
                      {grades?.map((grade) => (
                        <SelectItem key={grade.id} value={grade.id}>
                          {grade.name} {grade.section && `- Section ${grade.section}`}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-end">
                  <Button
                    variant="outline"
                    onClick={() => setSelectedGrade("all")}
                    className="w-full"
                    data-testid="button-clear-grade"
                  >
                    Clear Filter
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Fee Structure Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {structureLoading ? (
              Array.from({ length: 6 }).map((_, index) => (
                <Card key={index}>
                  <CardContent className="p-6">
                    <div className="flex items-center mb-4">
                      <Skeleton className="w-12 h-12 rounded-lg" />
                      <div className="ml-4 flex-1">
                        <Skeleton className="h-5 w-24 mb-2" />
                        <Skeleton className="h-4 w-32" />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-4 w-20" />
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : feeStructure?.length === 0 ? (
              <div className="col-span-full text-center py-12">
                <DollarSign className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-600 mb-2">No Fee Structure Found</h3>
                <p className="text-gray-500">Add fee structure to get started</p>
              </div>
            ) : (
              feeStructure?.map((fee, index) => (
                <Card key={fee.id} data-testid={`fee-structure-card-${fee.id}`}>
                  <CardContent className="p-6">
                    <div className="flex items-center mb-4">
                      <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        <DollarSign className="h-6 w-6 text-blue-600" />
                      </div>
                      <div className="ml-4 flex-1">
                        <Badge className={getFeeTypeColor(index)} data-testid={`fee-type-${fee.id}`}>
                          {fee.feeType}
                        </Badge>
                        <p className="text-sm text-gray-600 mt-1" data-testid={`fee-grade-${fee.id}`}>
                          {getGradeName(fee.gradeId)}
                        </p>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600">Amount:</span>
                        <span className="font-bold text-lg text-gray-900" data-testid={`fee-amount-${fee.id}`}>
                          ${Number(fee.amount).toLocaleString()}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600">Frequency:</span>
                        <span className="text-sm font-medium text-gray-900 capitalize" data-testid={`fee-frequency-${fee.id}`}>
                          {fee.frequency}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600">Academic Year:</span>
                        <span className="text-sm font-medium text-gray-900" data-testid={`fee-year-${fee.id}`}>
                          {fee.academicYear}
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </TabsContent>

        <TabsContent value="payments" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold text-gray-900">Payment Records</h2>
            <Button
              onClick={() => setShowPaymentModal(true)}
              disabled={!selectedStudent}
              className="bg-blue-600 hover:bg-blue-700 text-white flex items-center space-x-2 disabled:opacity-50"
              data-testid="button-add-payment"
            >
              <Plus className="h-4 w-4" />
              <span>Record Payment</span>
            </Button>
          </div>

          {/* Student Filter */}
          <Card>
            <CardContent className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Select Student</label>
                  <Select value={selectedStudent} onValueChange={setSelectedStudent}>
                    <SelectTrigger data-testid="select-student-payments">
                      <SelectValue placeholder="All Students" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Students</SelectItem>
                      {students?.students.map((student) => (
                        <SelectItem key={student.id} value={student.id}>
                          {student.firstName} {student.lastName} ({student.studentId})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-end">
                  <Button
                    variant="outline"
                    onClick={() => setSelectedStudent("all")}
                    className="w-full"
                    data-testid="button-clear-student"
                  >
                    Clear Filter
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Payments Table */}
          <Card>
            <CardContent>
              {paymentsLoading ? (
                <div className="space-y-4 p-6">
                  {Array.from({ length: 5 }).map((_, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-4">
                        <Skeleton className="w-10 h-10 rounded-lg" />
                        <div className="space-y-2">
                          <Skeleton className="h-4 w-32" />
                          <Skeleton className="h-3 w-24" />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Skeleton className="h-4 w-20" />
                        <Skeleton className="h-6 w-16 rounded-full" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : feePayments?.length === 0 ? (
                <div className="text-center py-12">
                  <Receipt className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-600 mb-2">No Payments Found</h3>
                  <p className="text-gray-500">
                    {selectedStudent ? "No payments recorded for this student" : "Select a student to view payment records"}
                  </p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Student
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Amount
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Payment Method
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Date
                        </th>
                        <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Status
                        </th>
                        <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Receipt
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {feePayments?.map((payment) => (
                        <tr key={payment.id} className="hover:bg-gray-50" data-testid={`payment-row-${payment.id}`}>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center">
                              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                                <CreditCard className="h-4 w-4 text-blue-600" />
                              </div>
                              <div className="ml-3">
                                <div className="text-sm font-medium text-gray-900" data-testid={`payment-student-${payment.id}`}>
                                  {getStudentName(payment.studentId)}
                                </div>
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm font-bold text-gray-900" data-testid={`payment-amount-${payment.id}`}>
                              ${Number(payment.amount).toLocaleString()}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-900 capitalize" data-testid={`payment-method-${payment.id}`}>
                              {payment.paymentMethod || "Cash"}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900" data-testid={`payment-date-${payment.id}`}>
                            {new Date(payment.paymentDate).toLocaleDateString()}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-center">
                            <Badge className={getStatusBadge(payment.status || "paid")} data-testid={`payment-status-${payment.id}`}>
                              {payment.status || "paid"}
                            </Badge>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-right text-sm text-gray-900" data-testid={`payment-receipt-${payment.id}`}>
                            {payment.receiptNumber || "N/A"}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <FeeStructureModal
        isOpen={showStructureModal}
        onClose={() => setShowStructureModal(false)}
        grades={grades || []}
      />

      <FeePaymentModal
        isOpen={showPaymentModal}
        onClose={() => setShowPaymentModal(false)}
        studentId={selectedStudent}
        students={students?.students || []}
        feeStructure={feeStructure || []}
      />
    </div>
  );
}
