# Overview

EduManage is a comprehensive school management system built as a full-stack web application. It provides tools for managing students, teachers, courses, attendance, grades, fees, and generating reports. The system is designed for school administrators, teachers, and potentially parents to efficiently handle various school operations.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **Routing**: Wouter for client-side routing with conditional rendering based on authentication state
- **UI Components**: shadcn/ui component library built on top of Radix UI primitives
- **Styling**: Tailwind CSS with custom design system variables and dark mode support
- **State Management**: TanStack React Query for server state management and caching
- **Forms**: React Hook Form with Zod validation for type-safe form handling

## Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Authentication**: OpenID Connect (OIDC) integration with Replit authentication
- **Session Management**: Express sessions with PostgreSQL session store
- **API Design**: RESTful API with structured error handling and logging middleware

## Database Design
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Schema**: Comprehensive relational schema covering:
  - User management (users, sessions)
  - Student records (students, grades, attendance)
  - Staff management (teachers)
  - Academic structure (courses, grades, student-grades relationships)
  - Financial management (fee structures, payments)
- **Migrations**: Database migrations managed through Drizzle Kit
- **Type Safety**: Full TypeScript integration with Zod schema validation

## Authentication & Security
- **Provider**: Replit OIDC authentication with automatic user provisioning
- **Session Storage**: Secure session management with PostgreSQL backing
- **Route Protection**: Middleware-based authentication checks on both client and server
- **CSRF Protection**: Session-based security with HTTP-only cookies

## Development Environment
- **Development Server**: Vite dev server with HMR and error overlay
- **Code Quality**: TypeScript strict mode with comprehensive type checking
- **Build Process**: Vite for frontend bundling, esbuild for backend compilation
- **Path Aliases**: Configured for clean imports (@/, @shared/, @assets/)

# External Dependencies

## Database Services
- **PostgreSQL**: Primary database via Neon Database serverless connection
- **Connection Pooling**: @neondatabase/serverless with WebSocket support

## Authentication Services
- **Replit OIDC**: OpenID Connect integration for user authentication
- **Session Management**: connect-pg-simple for PostgreSQL session storage

## UI & Styling
- **Component Library**: Comprehensive Radix UI primitives (@radix-ui/react-*)
- **Styling Framework**: Tailwind CSS with PostCSS processing
- **Icons**: Lucide React icon library
- **Utilities**: class-variance-authority for component variants, clsx for conditional classes

## Development Tools
- **Build Tools**: Vite with React plugin, esbuild for production builds
- **Replit Integration**: @replit/vite-plugin-cartographer and runtime error modal
- **Form Handling**: React Hook Form with Zod resolvers for validation
- **Date Handling**: date-fns for date manipulation and formatting

## Data Management
- **Query Management**: TanStack React Query for server state, caching, and synchronization
- **ORM**: Drizzle ORM with Zod integration for type-safe database operations
- **Validation**: Zod schemas for runtime type validation and form validation