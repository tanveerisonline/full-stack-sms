import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { ReportGenerator } from "./reports";
import * as path from "path";
import * as fs from "fs";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const reportGenerator = new ReportGenerator();
import { 
  insertStudentSchema, 
  insertTeacherSchema, 
  insertGradeSchema, 
  insertCourseSchema, 
  insertAttendanceSchema,
  insertStudentGradeSchema,
  insertFeeStructureSchema,
  insertFeePaymentSchema 
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Dashboard metrics
  app.get("/api/dashboard/metrics", isAuthenticated, async (req, res) => {
    try {
      const metrics = await storage.getDashboardMetrics();
      res.json(metrics);
    } catch (error) {
      console.error("Error fetching dashboard metrics:", error);
      res.status(500).json({ message: "Failed to fetch dashboard metrics" });
    }
  });

  // Student routes
  app.get("/api/students", isAuthenticated, async (req, res) => {
    try {
      const { search, gradeId, status, page = '1', limit = '10' } = req.query;
      const offset = (parseInt(page as string) - 1) * parseInt(limit as string);
      
      const result = await storage.getStudents({
        search: search as string,
        gradeId: gradeId as string,
        status: status as string,
        limit: parseInt(limit as string),
        offset,
      });
      
      res.json(result);
    } catch (error) {
      console.error("Error fetching students:", error);
      res.status(500).json({ message: "Failed to fetch students" });
    }
  });

  app.get("/api/students/:id", isAuthenticated, async (req, res) => {
    try {
      const student = await storage.getStudentById(req.params.id);
      if (!student) {
        return res.status(404).json({ message: "Student not found" });
      }
      res.json(student);
    } catch (error) {
      console.error("Error fetching student:", error);
      res.status(500).json({ message: "Failed to fetch student" });
    }
  });

  app.post("/api/students", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertStudentSchema.parse(req.body);
      const student = await storage.createStudent(validatedData);
      res.status(201).json(student);
    } catch (error) {
      console.error("Error creating student:", error);
      res.status(400).json({ message: "Failed to create student" });
    }
  });

  app.put("/api/students/:id", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertStudentSchema.partial().parse(req.body);
      const student = await storage.updateStudent(req.params.id, validatedData);
      res.json(student);
    } catch (error) {
      console.error("Error updating student:", error);
      res.status(400).json({ message: "Failed to update student" });
    }
  });

  app.delete("/api/students/:id", isAuthenticated, async (req, res) => {
    try {
      await storage.deleteStudent(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting student:", error);
      res.status(500).json({ message: "Failed to delete student" });
    }
  });

  // Teacher routes
  app.get("/api/teachers", isAuthenticated, async (req, res) => {
    try {
      const { search, subject, status } = req.query;
      const teachers = await storage.getTeachers({
        search: search as string,
        subject: subject as string,
        status: status as string,
      });
      res.json(teachers);
    } catch (error) {
      console.error("Error fetching teachers:", error);
      res.status(500).json({ message: "Failed to fetch teachers" });
    }
  });

  app.get("/api/teachers/:id", isAuthenticated, async (req, res) => {
    try {
      const teacher = await storage.getTeacherById(req.params.id);
      if (!teacher) {
        return res.status(404).json({ message: "Teacher not found" });
      }
      res.json(teacher);
    } catch (error) {
      console.error("Error fetching teacher:", error);
      res.status(500).json({ message: "Failed to fetch teacher" });
    }
  });

  app.post("/api/teachers", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertTeacherSchema.parse(req.body);
      const teacher = await storage.createTeacher(validatedData);
      res.status(201).json(teacher);
    } catch (error) {
      console.error("Error creating teacher:", error);
      res.status(400).json({ message: "Failed to create teacher" });
    }
  });

  app.put("/api/teachers/:id", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertTeacherSchema.partial().parse(req.body);
      const teacher = await storage.updateTeacher(req.params.id, validatedData);
      res.json(teacher);
    } catch (error) {
      console.error("Error updating teacher:", error);
      res.status(400).json({ message: "Failed to update teacher" });
    }
  });

  app.delete("/api/teachers/:id", isAuthenticated, async (req, res) => {
    try {
      await storage.deleteTeacher(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting teacher:", error);
      res.status(500).json({ message: "Failed to delete teacher" });
    }
  });

  // Grade routes
  app.get("/api/grades", isAuthenticated, async (req, res) => {
    try {
      const grades = await storage.getGrades();
      res.json(grades);
    } catch (error) {
      console.error("Error fetching grades:", error);
      res.status(500).json({ message: "Failed to fetch grades" });
    }
  });

  app.post("/api/grades", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertGradeSchema.parse(req.body);
      const grade = await storage.createGrade(validatedData);
      res.status(201).json(grade);
    } catch (error) {
      console.error("Error creating grade:", error);
      res.status(400).json({ message: "Failed to create grade" });
    }
  });

  // Course routes
  app.get("/api/courses", isAuthenticated, async (req, res) => {
    try {
      const { gradeId } = req.query;
      const courses = await storage.getCourses(gradeId as string);
      res.json(courses);
    } catch (error) {
      console.error("Error fetching courses:", error);
      res.status(500).json({ message: "Failed to fetch courses" });
    }
  });

  app.post("/api/courses", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertCourseSchema.parse(req.body);
      const course = await storage.createCourse(validatedData);
      res.status(201).json(course);
    } catch (error) {
      console.error("Error creating course:", error);
      res.status(400).json({ message: "Failed to create course" });
    }
  });

  // Attendance routes
  app.get("/api/attendance", isAuthenticated, async (req, res) => {
    try {
      const { date, studentId, gradeId } = req.query;
      const attendance = await storage.getAttendance({
        date: date as string,
        studentId: studentId as string,
        gradeId: gradeId as string,
      });
      res.json(attendance);
    } catch (error) {
      console.error("Error fetching attendance:", error);
      res.status(500).json({ message: "Failed to fetch attendance" });
    }
  });

  app.get("/api/attendance/stats", isAuthenticated, async (req, res) => {
    try {
      const { date } = req.query;
      const stats = await storage.getAttendanceStats(date as string);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching attendance stats:", error);
      res.status(500).json({ message: "Failed to fetch attendance stats" });
    }
  });

  app.post("/api/attendance", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertAttendanceSchema.parse(req.body);
      const attendance = await storage.markAttendance(validatedData);
      res.status(201).json(attendance);
    } catch (error) {
      console.error("Error marking attendance:", error);
      res.status(400).json({ message: "Failed to mark attendance" });
    }
  });

  // Student grades routes
  app.get("/api/students/:studentId/grades", isAuthenticated, async (req, res) => {
    try {
      const { courseId } = req.query;
      const grades = await storage.getStudentGrades(req.params.studentId, courseId as string);
      res.json(grades);
    } catch (error) {
      console.error("Error fetching student grades:", error);
      res.status(500).json({ message: "Failed to fetch student grades" });
    }
  });

  app.post("/api/grades", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertStudentGradeSchema.parse(req.body);
      const grade = await storage.addStudentGrade(validatedData);
      res.status(201).json(grade);
    } catch (error) {
      console.error("Error adding grade:", error);
      res.status(400).json({ message: "Failed to add grade" });
    }
  });

  // Fee routes
  app.get("/api/fee-structure", isAuthenticated, async (req, res) => {
    try {
      const { gradeId } = req.query;
      const feeStructure = await storage.getFeeStructure(gradeId as string);
      res.json(feeStructure);
    } catch (error) {
      console.error("Error fetching fee structure:", error);
      res.status(500).json({ message: "Failed to fetch fee structure" });
    }
  });

  app.post("/api/fee-structure", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertFeeStructureSchema.parse(req.body);
      const feeStructure = await storage.createFeeStructure(validatedData);
      res.status(201).json(feeStructure);
    } catch (error) {
      console.error("Error creating fee structure:", error);
      res.status(400).json({ message: "Failed to create fee structure" });
    }
  });

  app.get("/api/fee-payments", isAuthenticated, async (req, res) => {
    try {
      const { studentId } = req.query;
      const payments = await storage.getFeePayments(studentId as string);
      res.json(payments);
    } catch (error) {
      console.error("Error fetching fee payments:", error);
      res.status(500).json({ message: "Failed to fetch fee payments" });
    }
  });

  app.post("/api/fee-payments", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertFeePaymentSchema.parse(req.body);
      const payment = await storage.addFeePayment(validatedData);
      res.status(201).json(payment);
    } catch (error) {
      console.error("Error adding fee payment:", error);
      res.status(400).json({ message: "Failed to add fee payment" });
    }
  });

  // Reports routes
  app.post("/api/reports/generate", isAuthenticated, async (req, res) => {
    try {
      const { reportType, format, dateFrom, dateTo, gradeId, courseId, examType, feeType, status } = req.body;
      
      // Role-based data filtering
      const user = req.user as any;
      const userRole = user.claims?.role || 'admin';
      
      let data: any[] = [];
      let title = '';
      let filename = '';
      
      // Generate report data based on type
      switch (reportType) {
        case 'student':
          data = await storage.generateStudentReport({
            gradeId: userRole === 'teacher' ? gradeId : gradeId, // Teachers can see all for now
            status,
            dateFrom,
            dateTo
          });
          title = 'Student Report';
          filename = 'student_report';
          break;
          
        case 'attendance':
          data = await storage.generateAttendanceReport({
            gradeId,
            dateFrom,
            dateTo
          });
          title = 'Attendance Report';
          filename = 'attendance_report';
          break;
          
        case 'academic':
          data = await storage.generateAcademicReport({
            gradeId,
            courseId,
            examType,
            dateFrom,
            dateTo
          });
          title = 'Academic Performance Report';
          filename = 'academic_report';
          break;
          
        case 'financial':
          // Only admins can access financial reports
          if (userRole !== 'admin') {
            return res.status(403).json({ message: "Access denied. Admin role required for financial reports." });
          }
          data = await storage.generateFinancialReport({
            gradeId,
            feeType,
            status,
            dateFrom,
            dateTo
          });
          title = 'Financial Report';
          filename = 'financial_report';
          break;
          
        default:
          return res.status(400).json({ message: "Invalid report type" });
      }
      
      // Generate file based on format
      let generatedFilename = '';
      
      if (format === 'pdf') {
        switch (reportType) {
          case 'student':
            generatedFilename = await reportGenerator.generateStudentReportPDF(data, title);
            break;
          case 'attendance':
            generatedFilename = await reportGenerator.generateAttendanceReportPDF(data, title);
            break;
          case 'academic':
            generatedFilename = await reportGenerator.generateAcademicReportPDF(data, title);
            break;
          case 'financial':
            generatedFilename = await reportGenerator.generateFinancialReportPDF(data, title);
            break;
        }
      } else if (format === 'csv') {
        const columns = Object.keys(data[0] || {});
        generatedFilename = await reportGenerator.generateCSV(data, columns, filename);
      }
      
      res.json({ 
        filename: generatedFilename, 
        message: "Report generated successfully",
        recordCount: data.length 
      });
    } catch (error) {
      console.error("Error generating report:", error);
      res.status(500).json({ message: "Failed to generate report" });
    }
  });
  
  // Download report file
  app.get("/api/reports/download/:filename", isAuthenticated, async (req, res) => {
    try {
      const { filename } = req.params;
      const reportsDir = path.join(__dirname, '..', 'generated_reports');
      const filePath = path.join(reportsDir, filename);
      
      // Check if file exists
      if (!fs.existsSync(filePath)) {
        return res.status(404).json({ message: "Report file not found" });
      }
      
      // Set appropriate headers
      const ext = path.extname(filename).toLowerCase();
      if (ext === '.pdf') {
        res.setHeader('Content-Type', 'application/pdf');
      } else if (ext === '.csv') {
        res.setHeader('Content-Type', 'text/csv');
      }
      
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      
      // Send file
      res.sendFile(filePath);
    } catch (error) {
      console.error("Error downloading report:", error);
      res.status(500).json({ message: "Failed to download report" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
