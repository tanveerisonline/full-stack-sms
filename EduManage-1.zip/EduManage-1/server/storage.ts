import {
  users,
  students,
  teachers,
  grades,
  courses,
  attendance,
  studentGrades,
  feeStructure,
  feePayments,
  type User,
  type UpsertUser,
  type Student,
  type InsertStudent,
  type Teacher,
  type InsertTeacher,
  type Grade,
  type InsertGrade,
  type Course,
  type InsertCourse,
  type Attendance,
  type InsertAttendance,
  type StudentGrade,
  type InsertStudentGrade,
  type FeeStructure,
  type InsertFeeStructure,
  type FeePayment,
  type InsertFeePayment,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gte, lte, like, sql, count } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Student operations
  getStudents(params?: { search?: string; gradeId?: string; status?: string; limit?: number; offset?: number }): Promise<{ students: Student[]; total: number }>;
  getStudentById(id: string): Promise<Student | undefined>;
  createStudent(student: InsertStudent): Promise<Student>;
  updateStudent(id: string, student: Partial<InsertStudent>): Promise<Student>;
  deleteStudent(id: string): Promise<void>;
  
  // Teacher operations
  getTeachers(params?: { search?: string; subject?: string; status?: string }): Promise<Teacher[]>;
  getTeacherById(id: string): Promise<Teacher | undefined>;
  createTeacher(teacher: InsertTeacher): Promise<Teacher>;
  updateTeacher(id: string, teacher: Partial<InsertTeacher>): Promise<Teacher>;
  deleteTeacher(id: string): Promise<void>;
  
  // Grade/Class operations
  getGrades(): Promise<Grade[]>;
  getGradeById(id: string): Promise<Grade | undefined>;
  createGrade(grade: InsertGrade): Promise<Grade>;
  updateGrade(id: string, grade: Partial<InsertGrade>): Promise<Grade>;
  deleteGrade(id: string): Promise<void>;
  
  // Course operations
  getCourses(gradeId?: string): Promise<Course[]>;
  getCourseById(id: string): Promise<Course | undefined>;
  createCourse(course: InsertCourse): Promise<Course>;
  updateCourse(id: string, course: Partial<InsertCourse>): Promise<Course>;
  deleteCourse(id: string): Promise<void>;
  
  // Attendance operations
  getAttendance(params: { date?: string; studentId?: string; gradeId?: string }): Promise<Attendance[]>;
  markAttendance(attendance: InsertAttendance): Promise<Attendance>;
  updateAttendance(id: string, attendance: Partial<InsertAttendance>): Promise<Attendance>;
  getAttendanceStats(date?: string): Promise<{ present: number; absent: number; late: number; rate: number }>;
  
  // Grade/Marks operations
  getStudentGrades(studentId: string, courseId?: string): Promise<StudentGrade[]>;
  addStudentGrade(grade: InsertStudentGrade): Promise<StudentGrade>;
  updateStudentGrade(id: string, grade: Partial<InsertStudentGrade>): Promise<StudentGrade>;
  
  // Fee operations
  getFeeStructure(gradeId?: string): Promise<FeeStructure[]>;
  createFeeStructure(feeStructure: InsertFeeStructure): Promise<FeeStructure>;
  getFeePayments(studentId?: string): Promise<FeePayment[]>;
  addFeePayment(payment: InsertFeePayment): Promise<FeePayment>;
  
  // Dashboard metrics
  getDashboardMetrics(): Promise<{
    totalStudents: number;
    totalTeachers: number;
    todayAttendance: number;
    monthlyRevenue: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Student operations
  async getStudents(params?: { search?: string; gradeId?: string; status?: string; limit?: number; offset?: number }): Promise<{ students: Student[]; total: number }> {
    let query = db.select().from(students);
    let countQuery = db.select({ count: sql<number>`count(*)` }).from(students);
    
    const conditions = [];
    
    if (params?.search) {
      const searchCondition = like(students.firstName, `%${params.search}%`);
      conditions.push(searchCondition);
    }
    
    if (params?.gradeId) {
      conditions.push(eq(students.gradeId, params.gradeId));
    }
    
    if (params?.status) {
      conditions.push(eq(students.status, params.status));
    }
    
    if (conditions.length > 0) {
      const whereCondition = conditions.length === 1 ? conditions[0] : and(...conditions);
      query = query.where(whereCondition);
      countQuery = countQuery.where(whereCondition);
    }
    
    query = query.orderBy(desc(students.createdAt));
    
    if (params?.limit) {
      query = query.limit(params.limit);
    }
    
    if (params?.offset) {
      query = query.offset(params.offset);
    }
    
    const [studentsResult, countResult] = await Promise.all([
      query.execute(),
      countQuery.execute()
    ]);
    
    return {
      students: studentsResult,
      total: countResult[0]?.count || 0
    };
  }

  async getStudentById(id: string): Promise<Student | undefined> {
    const [student] = await db.select().from(students).where(eq(students.id, id));
    return student;
  }

  async createStudent(student: InsertStudent): Promise<Student> {
    // Handle undefined/null/empty fields by setting them to null for proper database insertion
    const studentData = {
      ...student,
      gradeId: student.gradeId || null,
      dateOfBirth: student.dateOfBirth && student.dateOfBirth.trim() !== "" ? student.dateOfBirth : null,
      enrollmentDate: student.enrollmentDate && student.enrollmentDate.trim() !== "" ? student.enrollmentDate : null,
      email: student.email && student.email.trim() !== "" ? student.email : null,
      phone: student.phone && student.phone.trim() !== "" ? student.phone : null,
      address: student.address && student.address.trim() !== "" ? student.address : null,
      parentName: student.parentName && student.parentName.trim() !== "" ? student.parentName : null,
      parentEmail: student.parentEmail && student.parentEmail.trim() !== "" ? student.parentEmail : null,
      parentPhone: student.parentPhone && student.parentPhone.trim() !== "" ? student.parentPhone : null,
    };
    
    const [newStudent] = await db.insert(students).values(studentData).returning();
    return newStudent;
  }

  async updateStudent(id: string, student: Partial<InsertStudent>): Promise<Student> {
    // Handle undefined/null/empty fields by setting them to null for proper database insertion
    const studentData = {
      ...student,
      gradeId: student.gradeId || null,
      dateOfBirth: student.dateOfBirth && student.dateOfBirth.trim() !== "" ? student.dateOfBirth : null,
      enrollmentDate: student.enrollmentDate && student.enrollmentDate.trim() !== "" ? student.enrollmentDate : null,
      email: student.email && student.email.trim() !== "" ? student.email : null,
      phone: student.phone && student.phone.trim() !== "" ? student.phone : null,
      address: student.address && student.address.trim() !== "" ? student.address : null,
      parentName: student.parentName && student.parentName.trim() !== "" ? student.parentName : null,
      parentEmail: student.parentEmail && student.parentEmail.trim() !== "" ? student.parentEmail : null,
      parentPhone: student.parentPhone && student.parentPhone.trim() !== "" ? student.parentPhone : null,
      updatedAt: new Date(),
    };
    
    const [updatedStudent] = await db
      .update(students)
      .set(studentData)
      .where(eq(students.id, id))
      .returning();
    return updatedStudent;
  }

  async deleteStudent(id: string): Promise<void> {
    await db.delete(students).where(eq(students.id, id));
  }

  // Teacher operations
  async getTeachers(params?: { search?: string; subject?: string; status?: string }): Promise<Teacher[]> {
    let query = db.select().from(teachers);
    
    const conditions = [];
    
    if (params?.search) {
      conditions.push(like(teachers.firstName, `%${params.search}%`));
    }
    
    if (params?.subject) {
      conditions.push(eq(teachers.subject, params.subject));
    }
    
    if (params?.status) {
      conditions.push(eq(teachers.status, params.status));
    }
    
    if (conditions.length > 0) {
      query = query.where(conditions.length === 1 ? conditions[0] : and(...conditions));
    }
    
    return await query.orderBy(desc(teachers.createdAt)).execute();
  }

  async getTeacherById(id: string): Promise<Teacher | undefined> {
    const [teacher] = await db.select().from(teachers).where(eq(teachers.id, id));
    return teacher;
  }

  async createTeacher(teacher: InsertTeacher): Promise<Teacher> {
    // Handle undefined/null/empty fields by setting them to null for proper database insertion
    const teacherData = {
      ...teacher,
      email: teacher.email && teacher.email.trim() !== "" ? teacher.email : null,
      phone: teacher.phone && teacher.phone.trim() !== "" ? teacher.phone : null,
      address: teacher.address && teacher.address.trim() !== "" ? teacher.address : null,
      subject: teacher.subject && teacher.subject.trim() !== "" ? teacher.subject : null,
      qualification: teacher.qualification && teacher.qualification.trim() !== "" ? teacher.qualification : null,
      hireDate: teacher.hireDate && teacher.hireDate.trim() !== "" ? teacher.hireDate : null,
    };
    
    const [newTeacher] = await db.insert(teachers).values(teacherData).returning();
    return newTeacher;
  }

  async updateTeacher(id: string, teacher: Partial<InsertTeacher>): Promise<Teacher> {
    // Handle undefined/null/empty fields by setting them to null for proper database insertion
    const teacherData = {
      ...teacher,
      email: teacher.email && teacher.email.trim() !== "" ? teacher.email : null,
      phone: teacher.phone && teacher.phone.trim() !== "" ? teacher.phone : null,
      address: teacher.address && teacher.address.trim() !== "" ? teacher.address : null,
      subject: teacher.subject && teacher.subject.trim() !== "" ? teacher.subject : null,
      qualification: teacher.qualification && teacher.qualification.trim() !== "" ? teacher.qualification : null,
      hireDate: teacher.hireDate && teacher.hireDate.trim() !== "" ? teacher.hireDate : null,
      updatedAt: new Date(),
    };
    
    const [updatedTeacher] = await db
      .update(teachers)
      .set(teacherData)
      .where(eq(teachers.id, id))
      .returning();
    return updatedTeacher;
  }

  async deleteTeacher(id: string): Promise<void> {
    await db.delete(teachers).where(eq(teachers.id, id));
  }

  // Grade operations
  async getGrades(): Promise<Grade[]> {
    return await db.select().from(grades).orderBy(grades.name);
  }

  async getGradeById(id: string): Promise<Grade | undefined> {
    const [grade] = await db.select().from(grades).where(eq(grades.id, id));
    return grade;
  }

  async createGrade(grade: InsertGrade): Promise<Grade> {
    const [newGrade] = await db.insert(grades).values(grade).returning();
    return newGrade;
  }

  async updateGrade(id: string, grade: Partial<InsertGrade>): Promise<Grade> {
    const [updatedGrade] = await db
      .update(grades)
      .set({ ...grade, updatedAt: new Date() })
      .where(eq(grades.id, id))
      .returning();
    return updatedGrade;
  }

  async deleteGrade(id: string): Promise<void> {
    await db.delete(grades).where(eq(grades.id, id));
  }

  // Course operations
  async getCourses(gradeId?: string): Promise<Course[]> {
    let query = db.select().from(courses);
    
    if (gradeId) {
      query = query.where(eq(courses.gradeId, gradeId));
    }
    
    return await query.orderBy(courses.name).execute();
  }

  async getCourseById(id: string): Promise<Course | undefined> {
    const [course] = await db.select().from(courses).where(eq(courses.id, id));
    return course;
  }

  async createCourse(course: InsertCourse): Promise<Course> {
    const [newCourse] = await db.insert(courses).values(course).returning();
    return newCourse;
  }

  async updateCourse(id: string, course: Partial<InsertCourse>): Promise<Course> {
    const [updatedCourse] = await db
      .update(courses)
      .set({ ...course, updatedAt: new Date() })
      .where(eq(courses.id, id))
      .returning();
    return updatedCourse;
  }

  async deleteCourse(id: string): Promise<void> {
    await db.delete(courses).where(eq(courses.id, id));
  }

  // Attendance operations
  async getAttendance(params: { date?: string; studentId?: string; gradeId?: string }): Promise<Attendance[]> {
    let query = db.select().from(attendance);
    
    const conditions = [];
    
    if (params.date) {
      conditions.push(eq(attendance.date, params.date));
    }
    
    if (params.studentId) {
      conditions.push(eq(attendance.studentId, params.studentId));
    }
    
    if (conditions.length > 0) {
      query = query.where(conditions.length === 1 ? conditions[0] : and(...conditions));
    }
    
    return await query.orderBy(desc(attendance.date)).execute();
  }

  async markAttendance(attendanceData: InsertAttendance): Promise<Attendance> {
    const [newAttendance] = await db.insert(attendance).values(attendanceData).returning();
    return newAttendance;
  }

  async updateAttendance(id: string, attendanceData: Partial<InsertAttendance>): Promise<Attendance> {
    const [updatedAttendance] = await db
      .update(attendance)
      .set(attendanceData)
      .where(eq(attendance.id, id))
      .returning();
    return updatedAttendance;
  }

  async getAttendanceStats(date?: string): Promise<{ present: number; absent: number; late: number; rate: number }> {
    let query = db.select().from(attendance);
    
    if (date) {
      query = query.where(eq(attendance.date, date));
    } else {
      // Default to today
      const today = new Date().toISOString().split('T')[0];
      query = query.where(eq(attendance.date, today));
    }
    
    const records = await query.execute();
    
    const present = records.filter(r => r.status === 'present').length;
    const absent = records.filter(r => r.status === 'absent').length;
    const late = records.filter(r => r.status === 'late').length;
    const total = records.length;
    const rate = total > 0 ? ((present + late) / total) * 100 : 0;
    
    return { present, absent, late, rate: Math.round(rate * 10) / 10 };
  }

  // Grade/Marks operations
  async getStudentGrades(studentId: string, courseId?: string): Promise<StudentGrade[]> {
    let query = db.select().from(studentGrades).where(eq(studentGrades.studentId, studentId));
    
    if (courseId) {
      query = query.where(and(eq(studentGrades.studentId, studentId), eq(studentGrades.courseId, courseId)));
    }
    
    return await query.orderBy(desc(studentGrades.examDate)).execute();
  }

  async addStudentGrade(grade: InsertStudentGrade): Promise<StudentGrade> {
    const [newGrade] = await db.insert(studentGrades).values(grade).returning();
    return newGrade;
  }

  async updateStudentGrade(id: string, grade: Partial<InsertStudentGrade>): Promise<StudentGrade> {
    const [updatedGrade] = await db
      .update(studentGrades)
      .set(grade)
      .where(eq(studentGrades.id, id))
      .returning();
    return updatedGrade;
  }

  // Fee operations
  async getFeeStructure(gradeId?: string): Promise<FeeStructure[]> {
    let query = db.select().from(feeStructure);
    
    if (gradeId) {
      query = query.where(eq(feeStructure.gradeId, gradeId));
    }
    
    return await query.orderBy(feeStructure.gradeId, feeStructure.feeType).execute();
  }

  async createFeeStructure(feeStructureData: InsertFeeStructure): Promise<FeeStructure> {
    const [newFeeStructure] = await db.insert(feeStructure).values(feeStructureData).returning();
    return newFeeStructure;
  }

  async getFeePayments(studentId?: string): Promise<FeePayment[]> {
    let query = db.select().from(feePayments);
    
    if (studentId) {
      query = query.where(eq(feePayments.studentId, studentId));
    }
    
    return await query.orderBy(desc(feePayments.paymentDate)).execute();
  }

  async addFeePayment(payment: InsertFeePayment): Promise<FeePayment> {
    const [newPayment] = await db.insert(feePayments).values(payment).returning();
    return newPayment;
  }

  // Dashboard metrics
  async getDashboardMetrics(): Promise<{
    totalStudents: number;
    totalTeachers: number;
    todayAttendance: number;
    monthlyRevenue: number;
  }> {
    const [studentCount] = await db.select({ count: sql<number>`count(*)` }).from(students).where(eq(students.status, 'active'));
    const [teacherCount] = await db.select({ count: sql<number>`count(*)` }).from(teachers).where(eq(teachers.status, 'active'));
    
    // Today's attendance rate
    const today = new Date().toISOString().split('T')[0];
    const todayAttendance = await this.getAttendanceStats(today);
    
    // Monthly revenue - sum of payments in current month
    const currentDate = new Date();
    const firstDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1).toISOString().split('T')[0];
    const lastDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).toISOString().split('T')[0];
    
    const [revenueResult] = await db
      .select({ sum: sql<number>`COALESCE(SUM(amount), 0)` })
      .from(feePayments)
      .where(and(
        gte(feePayments.paymentDate, firstDayOfMonth),
        lte(feePayments.paymentDate, lastDayOfMonth)
      ));
    
    return {
      totalStudents: studentCount?.count || 0,
      totalTeachers: teacherCount?.count || 0,
      todayAttendance: todayAttendance.rate,
      monthlyRevenue: Number(revenueResult?.sum) || 0,
    };
  }

  // Reports operations
  async generateStudentReport(params: { gradeId?: string; status?: string; dateFrom?: string; dateTo?: string }): Promise<any[]> {
    let query = db
      .select({
        id: students.id,
        studentId: students.studentId,
        firstName: students.firstName,
        lastName: students.lastName,
        email: students.email,
        phone: students.phone,
        dateOfBirth: students.dateOfBirth,
        address: students.address,
        parentName: students.parentName,
        parentEmail: students.parentEmail,
        status: students.status,
        enrollmentDate: students.enrollmentDate,
        gradeName: grades.name,
        gradeSection: grades.section,
      })
      .from(students)
      .leftJoin(grades, eq(students.gradeId, grades.id));

    const conditions = [];
    
    if (params.gradeId) {
      conditions.push(eq(students.gradeId, params.gradeId));
    }
    
    if (params.status) {
      conditions.push(eq(students.status, params.status));
    }
    
    if (params.dateFrom) {
      conditions.push(gte(students.enrollmentDate, params.dateFrom));
    }
    
    if (params.dateTo) {
      conditions.push(lte(students.enrollmentDate, params.dateTo));
    }
    
    if (conditions.length > 0) {
      query = query.where(conditions.length === 1 ? conditions[0] : and(...conditions));
    }
    
    return await query.execute();
  }

  async generateAttendanceReport(params: { gradeId?: string; dateFrom?: string; dateTo?: string }): Promise<any[]> {
    let query = db
      .select({
        studentId: students.studentId,
        firstName: students.firstName,
        lastName: students.lastName,
        gradeName: grades.name,
        gradeSection: grades.section,
        date: attendance.date,
        status: attendance.status,
        timeIn: attendance.timeIn,
        timeOut: attendance.timeOut,
        remarks: attendance.remarks,
      })
      .from(attendance)
      .innerJoin(students, eq(attendance.studentId, students.id))
      .leftJoin(grades, eq(students.gradeId, grades.id));

    const conditions = [];
    
    if (params.gradeId) {
      conditions.push(eq(students.gradeId, params.gradeId));
    }
    
    if (params.dateFrom) {
      conditions.push(gte(attendance.date, params.dateFrom));
    }
    
    if (params.dateTo) {
      conditions.push(lte(attendance.date, params.dateTo));
    }
    
    if (conditions.length > 0) {
      query = query.where(conditions.length === 1 ? conditions[0] : and(...conditions));
    }
    
    return await query.orderBy(desc(attendance.date)).execute();
  }

  async generateAcademicReport(params: { gradeId?: string; courseId?: string; examType?: string; dateFrom?: string; dateTo?: string }): Promise<any[]> {
    let query = db
      .select({
        studentId: students.studentId,
        firstName: students.firstName,
        lastName: students.lastName,
        gradeName: grades.name,
        courseName: courses.name,
        courseCode: courses.code,
        examType: studentGrades.examType,
        marks: studentGrades.marks,
        totalMarks: studentGrades.totalMarks,
        grade: studentGrades.grade,
        examDate: studentGrades.examDate,
      })
      .from(studentGrades)
      .innerJoin(students, eq(studentGrades.studentId, students.id))
      .innerJoin(courses, eq(studentGrades.courseId, courses.id))
      .leftJoin(grades, eq(students.gradeId, grades.id));

    const conditions = [];
    
    if (params.gradeId) {
      conditions.push(eq(students.gradeId, params.gradeId));
    }
    
    if (params.courseId) {
      conditions.push(eq(studentGrades.courseId, params.courseId));
    }
    
    if (params.examType) {
      conditions.push(eq(studentGrades.examType, params.examType));
    }
    
    if (params.dateFrom) {
      conditions.push(gte(studentGrades.examDate, params.dateFrom));
    }
    
    if (params.dateTo) {
      conditions.push(lte(studentGrades.examDate, params.dateTo));
    }
    
    if (conditions.length > 0) {
      query = query.where(conditions.length === 1 ? conditions[0] : and(...conditions));
    }
    
    return await query.orderBy(desc(studentGrades.examDate)).execute();
  }

  async generateFinancialReport(params: { gradeId?: string; feeType?: string; status?: string; dateFrom?: string; dateTo?: string }): Promise<any[]> {
    let query = db
      .select({
        studentId: students.studentId,
        firstName: students.firstName,
        lastName: students.lastName,
        gradeName: grades.name,
        feeType: feeStructure.feeType,
        amount: feePayments.amount,
        paymentDate: feePayments.paymentDate,
        paymentMethod: feePayments.paymentMethod,
        status: feePayments.status,
        dueDate: feePayments.dueDate,
        receiptNumber: feePayments.receiptNumber,
      })
      .from(feePayments)
      .innerJoin(students, eq(feePayments.studentId, students.id))
      .innerJoin(feeStructure, eq(feePayments.feeStructureId, feeStructure.id))
      .leftJoin(grades, eq(students.gradeId, grades.id));

    const conditions = [];
    
    if (params.gradeId) {
      conditions.push(eq(students.gradeId, params.gradeId));
    }
    
    if (params.feeType) {
      conditions.push(eq(feeStructure.feeType, params.feeType));
    }
    
    if (params.status) {
      conditions.push(eq(feePayments.status, params.status));
    }
    
    if (params.dateFrom) {
      conditions.push(gte(feePayments.paymentDate, params.dateFrom));
    }
    
    if (params.dateTo) {
      conditions.push(lte(feePayments.paymentDate, params.dateTo));
    }
    
    if (conditions.length > 0) {
      query = query.where(conditions.length === 1 ? conditions[0] : and(...conditions));
    }
    
    return await query.orderBy(desc(feePayments.paymentDate)).execute();
  }
}

export const storage = new DatabaseStorage();
