// @ts-ignore
import jsPDF from 'jspdf';
// @ts-ignore  
import 'jspdf-autotable';
import * as fs from 'fs';
import * as path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Extend jsPDF type to include autoTable
declare module 'jspdf' {
  interface jsPDF {
    autoTable: (options: any) => void;
  }
}

export class ReportGenerator {
  private ensureReportsDir(): string {
    const reportsDir = path.join(__dirname, '..', 'generated_reports');
    if (!fs.existsSync(reportsDir)) {
      fs.mkdirSync(reportsDir, { recursive: true });
    }
    return reportsDir;
  }

  async generateStudentReportPDF(data: any[], title: string): Promise<string> {
    const doc = new jsPDF();
    const reportsDir = this.ensureReportsDir();
    
    // Add title
    doc.setFontSize(16);
    doc.text(title, 20, 20);
    doc.setFontSize(12);
    doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 20, 30);
    
    // Prepare table data
    const tableColumns = [
      'Student ID', 'Name', 'Email', 'Grade', 'Status', 'Enrollment Date'
    ];
    
    const tableRows = data.map(student => [
      student.studentId || '',
      `${student.firstName} ${student.lastName}`,
      student.email || '',
      student.gradeName ? `${student.gradeName} ${student.gradeSection || ''}`.trim() : '',
      student.status || '',
      student.enrollmentDate || ''
    ]);
    
    // Add table
    doc.autoTable({
      head: [tableColumns],
      body: tableRows,
      startY: 40,
      theme: 'striped',
      headStyles: { fillColor: [66, 139, 202] }
    });
    
    // Save file
    const filename = `student_report_${Date.now()}.pdf`;
    const filepath = path.join(reportsDir, filename);
    doc.save(filepath);
    
    return filename;
  }

  async generateAttendanceReportPDF(data: any[], title: string): Promise<string> {
    const doc = new jsPDF();
    const reportsDir = this.ensureReportsDir();
    
    // Add title
    doc.setFontSize(16);
    doc.text(title, 20, 20);
    doc.setFontSize(12);
    doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 20, 30);
    
    // Prepare table data
    const tableColumns = [
      'Student ID', 'Name', 'Grade', 'Date', 'Status', 'Time In', 'Time Out'
    ];
    
    const tableRows = data.map(record => [
      record.studentId || '',
      `${record.firstName} ${record.lastName}`,
      record.gradeName ? `${record.gradeName} ${record.gradeSection || ''}`.trim() : '',
      record.date || '',
      record.status || '',
      record.timeIn || '',
      record.timeOut || ''
    ]);
    
    doc.autoTable({
      head: [tableColumns],
      body: tableRows,
      startY: 40,
      theme: 'striped',
      headStyles: { fillColor: [66, 139, 202] }
    });
    
    const filename = `attendance_report_${Date.now()}.pdf`;
    const filepath = path.join(reportsDir, filename);
    doc.save(filepath);
    
    return filename;
  }

  async generateAcademicReportPDF(data: any[], title: string): Promise<string> {
    const doc = new jsPDF();
    const reportsDir = this.ensureReportsDir();
    
    doc.setFontSize(16);
    doc.text(title, 20, 20);
    doc.setFontSize(12);
    doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 20, 30);
    
    const tableColumns = [
      'Student ID', 'Name', 'Course', 'Exam Type', 'Marks', 'Total', 'Grade'
    ];
    
    const tableRows = data.map(record => [
      record.studentId || '',
      `${record.firstName} ${record.lastName}`,
      `${record.courseName} (${record.courseCode})`,
      record.examType || '',
      record.marks ? record.marks.toString() : '',
      record.totalMarks ? record.totalMarks.toString() : '',
      record.grade || ''
    ]);
    
    doc.autoTable({
      head: [tableColumns],
      body: tableRows,
      startY: 40,
      theme: 'striped',
      headStyles: { fillColor: [66, 139, 202] }
    });
    
    const filename = `academic_report_${Date.now()}.pdf`;
    const filepath = path.join(reportsDir, filename);
    doc.save(filepath);
    
    return filename;
  }

  async generateFinancialReportPDF(data: any[], title: string): Promise<string> {
    const doc = new jsPDF();
    const reportsDir = this.ensureReportsDir();
    
    doc.setFontSize(16);
    doc.text(title, 20, 20);
    doc.setFontSize(12);
    doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 20, 30);
    
    const tableColumns = [
      'Student ID', 'Name', 'Fee Type', 'Amount', 'Payment Date', 'Status'
    ];
    
    const tableRows = data.map(record => [
      record.studentId || '',
      `${record.firstName} ${record.lastName}`,
      record.feeType || '',
      record.amount ? `$${record.amount}` : '',
      record.paymentDate || '',
      record.status || ''
    ]);
    
    doc.autoTable({
      head: [tableColumns],
      body: tableRows,
      startY: 40,
      theme: 'striped',
      headStyles: { fillColor: [66, 139, 202] }
    });
    
    const filename = `financial_report_${Date.now()}.pdf`;
    const filepath = path.join(reportsDir, filename);
    doc.save(filepath);
    
    return filename;
  }

  async generateCSV(data: any[], columns: string[], filename: string): Promise<string> {
    const reportsDir = this.ensureReportsDir();
    const csvContent = this.convertToCSV(data, columns);
    const csvFilename = `${filename}_${Date.now()}.csv`;
    const filepath = path.join(reportsDir, csvFilename);
    
    fs.writeFileSync(filepath, csvContent);
    return csvFilename;
  }

  private convertToCSV(data: any[], columns: string[]): string {
    const header = columns.join(',');
    const rows = data.map(row => 
      columns.map(column => {
        const value = this.getNestedValue(row, column);
        return `"${value || ''}"`;
      }).join(',')
    );
    
    return [header, ...rows].join('\n');
  }

  private getNestedValue(obj: any, path: string): any {
    return path.split('.').reduce((current, key) => current?.[key], obj);
  }
}