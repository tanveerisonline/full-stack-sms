import { sql } from 'drizzle-orm';
import { relations } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  integer,
  decimal,
  boolean,
  date,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table.
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table.
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  role: varchar("role").default("admin"), // admin, teacher, student, parent
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Students table
export const students = pgTable("students", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  studentId: varchar("student_id").unique().notNull(),
  firstName: varchar("first_name").notNull(),
  lastName: varchar("last_name").notNull(),
  email: varchar("email").unique(),
  phone: varchar("phone"),
  dateOfBirth: date("date_of_birth"),
  address: text("address"),
  parentName: varchar("parent_name"),
  parentEmail: varchar("parent_email"),
  parentPhone: varchar("parent_phone"),
  gradeId: varchar("grade_id").references(() => grades.id),
  status: varchar("status").default("active"), // active, inactive, graduated
  enrollmentDate: date("enrollment_date").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Teachers table
export const teachers = pgTable("teachers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  employeeId: varchar("employee_id").unique().notNull(),
  firstName: varchar("first_name").notNull(),
  lastName: varchar("last_name").notNull(),
  email: varchar("email").unique(),
  phone: varchar("phone"),
  address: text("address"),
  subject: varchar("subject"),
  qualification: text("qualification"),
  experience: integer("experience"), // in years
  salary: decimal("salary", { precision: 10, scale: 2 }),
  hireDate: date("hire_date"),
  status: varchar("status").default("active"), // active, inactive
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Grades/Classes table
export const grades = pgTable("grades", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(), // Grade 9, Grade 10, etc.
  section: varchar("section"), // A, B, C, etc.
  capacity: integer("capacity").default(30),
  teacherId: varchar("teacher_id").references(() => teachers.id),
  academicYear: varchar("academic_year").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Courses/Subjects table
export const courses = pgTable("courses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(),
  code: varchar("code").unique().notNull(),
  description: text("description"),
  credits: integer("credits").default(1),
  gradeId: varchar("grade_id").references(() => grades.id),
  teacherId: varchar("teacher_id").references(() => teachers.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Attendance table
export const attendance = pgTable("attendance", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  studentId: varchar("student_id").notNull().references(() => students.id),
  date: date("date").notNull(),
  status: varchar("status").notNull(), // present, absent, late
  timeIn: varchar("time_in"), // HH:MM format
  timeOut: varchar("time_out"), // HH:MM format
  remarks: text("remarks"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Student Grades/Marks table
export const studentGrades = pgTable("student_grades", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  studentId: varchar("student_id").notNull().references(() => students.id),
  courseId: varchar("course_id").notNull().references(() => courses.id),
  examType: varchar("exam_type").notNull(), // quiz, midterm, final, assignment
  marks: decimal("marks", { precision: 5, scale: 2 }).notNull(),
  totalMarks: decimal("total_marks", { precision: 5, scale: 2 }).notNull(),
  grade: varchar("grade"), // A+, A, B+, etc.
  examDate: date("exam_date"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Fee Structure table
export const feeStructure = pgTable("fee_structure", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  gradeId: varchar("grade_id").notNull().references(() => grades.id),
  feeType: varchar("fee_type").notNull(), // tuition, transport, library, etc.
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  frequency: varchar("frequency").default("monthly"), // monthly, quarterly, yearly
  academicYear: varchar("academic_year").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Fee Payments table
export const feePayments = pgTable("fee_payments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  studentId: varchar("student_id").notNull().references(() => students.id),
  feeStructureId: varchar("fee_structure_id").notNull().references(() => feeStructure.id),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  paymentDate: date("payment_date").notNull(),
  paymentMethod: varchar("payment_method"), // cash, card, online
  status: varchar("status").default("paid"), // paid, pending, overdue
  dueDate: date("due_date"),
  receiptNumber: varchar("receipt_number"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const studentsRelations = relations(students, ({ one, many }) => ({
  grade: one(grades, {
    fields: [students.gradeId],
    references: [grades.id],
  }),
  attendance: many(attendance),
  grades: many(studentGrades),
  feePayments: many(feePayments),
}));

export const teachersRelations = relations(teachers, ({ many }) => ({
  grades: many(grades),
  courses: many(courses),
}));

export const gradesRelations = relations(grades, ({ one, many }) => ({
  teacher: one(teachers, {
    fields: [grades.teacherId],
    references: [teachers.id],
  }),
  students: many(students),
  courses: many(courses),
  feeStructure: many(feeStructure),
}));

export const coursesRelations = relations(courses, ({ one, many }) => ({
  grade: one(grades, {
    fields: [courses.gradeId],
    references: [grades.id],
  }),
  teacher: one(teachers, {
    fields: [courses.teacherId],
    references: [teachers.id],
  }),
  studentGrades: many(studentGrades),
}));

export const attendanceRelations = relations(attendance, ({ one }) => ({
  student: one(students, {
    fields: [attendance.studentId],
    references: [students.id],
  }),
}));

export const studentGradesRelations = relations(studentGrades, ({ one }) => ({
  student: one(students, {
    fields: [studentGrades.studentId],
    references: [students.id],
  }),
  course: one(courses, {
    fields: [studentGrades.courseId],
    references: [courses.id],
  }),
}));

export const feeStructureRelations = relations(feeStructure, ({ one, many }) => ({
  grade: one(grades, {
    fields: [feeStructure.gradeId],
    references: [grades.id],
  }),
  payments: many(feePayments),
}));

export const feePaymentsRelations = relations(feePayments, ({ one }) => ({
  student: one(students, {
    fields: [feePayments.studentId],
    references: [students.id],
  }),
  feeStructure: one(feeStructure, {
    fields: [feePayments.feeStructureId],
    references: [feeStructure.id],
  }),
}));

// Insert schemas
export const insertStudentSchema = createInsertSchema(students).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertTeacherSchema = createInsertSchema(teachers).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertGradeSchema = createInsertSchema(grades).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCourseSchema = createInsertSchema(courses).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertAttendanceSchema = createInsertSchema(attendance).omit({
  id: true,
  createdAt: true,
});

export const insertStudentGradeSchema = createInsertSchema(studentGrades).omit({
  id: true,
  createdAt: true,
});

export const insertFeeStructureSchema = createInsertSchema(feeStructure).omit({
  id: true,
  createdAt: true,
});

export const insertFeePaymentSchema = createInsertSchema(feePayments).omit({
  id: true,
  createdAt: true,
});

// Types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

export type InsertStudent = z.infer<typeof insertStudentSchema>;
export type Student = typeof students.$inferSelect;

export type InsertTeacher = z.infer<typeof insertTeacherSchema>;
export type Teacher = typeof teachers.$inferSelect;

export type InsertGrade = z.infer<typeof insertGradeSchema>;
export type Grade = typeof grades.$inferSelect;

export type InsertCourse = z.infer<typeof insertCourseSchema>;
export type Course = typeof courses.$inferSelect;

export type InsertAttendance = z.infer<typeof insertAttendanceSchema>;
export type Attendance = typeof attendance.$inferSelect;

export type InsertStudentGrade = z.infer<typeof insertStudentGradeSchema>;
export type StudentGrade = typeof studentGrades.$inferSelect;

export type InsertFeeStructure = z.infer<typeof insertFeeStructureSchema>;
export type FeeStructure = typeof feeStructure.$inferSelect;

export type InsertFeePayment = z.infer<typeof insertFeePaymentSchema>;
export type FeePayment = typeof feePayments.$inferSelect;
