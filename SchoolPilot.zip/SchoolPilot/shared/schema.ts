// Legacy schema file - DEPRECATED
// Use individual schema files from ./schemas/ directory instead
// This file is kept for backward compatibility during migration

export * from './schemas';

// Legacy content removed - all schemas moved to individual files
// All exports now come from ./schemas/index.ts
