// Financial Management Hooks
// Add financial-specific hooks here as they are created