// Communication Management Hooks
// Add communication-specific hooks here as they are created