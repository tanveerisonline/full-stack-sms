// Library Management Hooks
// Add library-specific hooks here as they are created