// Academic Management Components
export { default as AssignmentModal } from './AssignmentModal';
export { default as ClassModal } from './ClassModal';
export { default as CourseModal } from './CourseModal';
export { default as GradeModal } from './GradeModal';
export { default as GradingModal } from './GradingModal';
export { default as SubmissionModal } from './SubmissionModal';