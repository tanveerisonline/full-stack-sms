<?php
// Newsletter subscription handler for Hostinger email integration
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit();
}

// Use PHP's built-in mail function for better Hostinger compatibility

function handleNewsletterSubscription() {
    try {
        // Get and validate input
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input || !isset($input['email'])) {
            throw new Exception('Email is required');
        }
        
        $email = filter_var(trim($input['email']), FILTER_VALIDATE_EMAIL);
        if (!$email) {
            throw new Exception('Please enter a valid email address');
        }
        
        // Prepare notification email to admin
        $to_admin = 'newsletter@thenexgendigital.com';
        $subject_admin = 'New Newsletter Subscription';
        $headers_admin = "From: newsletter@thenexgendigital.com\r\n";
        $headers_admin .= "Reply-To: {$email}\r\n";
        $headers_admin .= "MIME-Version: 1.0\r\n";
        $headers_admin .= "Content-Type: text/html; charset=UTF-8\r\n";
        
        $message_admin = "
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background-color: #2c3e50; color: white; padding: 20px; text-align: center; }
                .content { background-color: #f9f9f9; padding: 30px; }
                .info-row { margin: 10px 0; }
                .label { font-weight: bold; color: #2c3e50; }
                .footer { background-color: #34495e; color: white; padding: 15px; text-align: center; font-size: 12px; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h2>📧 New Newsletter Subscription</h2>
                </div>
                <div class='content'>
                    <p>You have received a new newsletter subscription:</p>
                    
                    <div class='info-row'>
                        <span class='label'>Email:</span> {$email}
                    </div>
                    
                    <div class='info-row'>
                        <span class='label'>Subscription Date:</span> " . date('Y-m-d H:i:s') . "
                    </div>
                    
                    <div class='info-row'>
                        <span class='label'>Source:</span> Website Newsletter Form
                    </div>
                </div>
                <div class='footer'>
                    <p>This email was sent from The Next Gen Digital website newsletter subscription form.</p>
                </div>
            </div>
        </body>
        </html>
        ";
        
        // Send notification email to admin
        mail($to_admin, $subject_admin, $message_admin, $headers_admin);
        
        // Send confirmation email to subscriber
        $to_subscriber = $email;
        $subject_subscriber = 'Welcome to The Next Gen Digital Newsletter!';
        $headers_subscriber = "From: newsletter@thenexgendigital.com\r\n";
        $headers_subscriber .= "MIME-Version: 1.0\r\n";
        $headers_subscriber .= "Content-Type: text/html; charset=UTF-8\r\n";
        
        $message_subscriber = "
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background-color: #2c3e50; color: white; padding: 20px; text-align: center; }
                .content { background-color: #f9f9f9; padding: 30px; }
                .footer { background-color: #34495e; color: white; padding: 15px; text-align: center; font-size: 12px; }
                .btn { display: inline-block; padding: 12px 24px; background-color: #3498db; color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h2>🎉 Welcome to Our Newsletter!</h2>
                </div>
                <div class='content'>
                    <p>Thank you for subscribing to The Next Gen Digital newsletter!</p>
                    
                    <p>You'll now receive:</p>
                    <ul>
                        <li>Weekly digital marketing insights</li>
                        <li>Latest industry trends and strategies</li>
                        <li>Exclusive tips and best practices</li>
                        <li>Updates on our latest blog posts</li>
                    </ul>
                    
                    <p>Stay ahead of the curve with news, strategies, and trends from the forefront of digital marketing.</p>
                    
                    <a href='https://thenexgendigital.com/blog' class='btn'>Read Our Latest Posts</a>
                </div>
                <div class='footer'>
                    <p>The Next Gen Digital | Digital Marketing Agency</p>
                    <p>If you no longer wish to receive these emails, you can unsubscribe at any time.</p>
                </div>
            </div>
        </body>
        </html>
        ";
        
        mail($to_subscriber, $subject_subscriber, $message_subscriber, $headers_subscriber);
        
        return [
            'success' => true,
            'message' => 'Thank you for subscribing! Please check your email for confirmation.'
        ];
        
    } catch (Exception $e) {
        error_log('Newsletter subscription error: ' . $e->getMessage());
        return [
            'success' => false,
            'message' => 'Sorry, there was an error processing your subscription. Please try again later.'
        ];
    }
}

// Handle the request
$result = handleNewsletterSubscription();
echo json_encode($result);
?>