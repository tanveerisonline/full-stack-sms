class ApplicationManager {
  constructor() {
    this.modal = document.getElementById('applicationModal');
    this.form = document.getElementById('applicationForm');
    this.closeBtn = document.querySelector('.close');
    this.cancelBtn = document.getElementById('cancelApplication');
    this.submitBtn = document.getElementById('submitApplication');
    this.positionInput = document.getElementById('position');
    this.fileInput = document.getElementById('resume');
    this.fileLabel = document.querySelector('.file-upload-label span');
    
    this.init();
  }

  init() {
    this.bindEvents();
    this.setupFileUpload();
  }

  bindEvents() {
    // Open modal when apply buttons are clicked
    document.querySelectorAll('.careers-apply-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        this.openModal(e.target);
      });
    });

    // Close modal events
    this.closeBtn.addEventListener('click', () => this.closeModal());
    this.cancelBtn.addEventListener('click', () => this.closeModal());
    
    // Close modal when clicking outside
    this.modal.addEventListener('click', (e) => {
      if (e.target === this.modal) {
        this.closeModal();
      }
    });

    // Close modal with Escape key
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && this.modal.style.display === 'block') {
        this.closeModal();
      }
    });

    // Form submission
    this.form.addEventListener('submit', (e) => {
      e.preventDefault();
      this.handleSubmit();
    });
  }

  setupFileUpload() {
    this.fileInput.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (file) {
        // Validate file size (5MB limit)
        if (file.size > 5 * 1024 * 1024) {
          alert('File size must be less than 5MB');
          this.fileInput.value = '';
          return;
        }

        // Validate file type
        const allowedTypes = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
        if (!allowedTypes.includes(file.type)) {
          alert('Please upload a PDF, DOC, or DOCX file');
          this.fileInput.value = '';
          return;
        }

        this.fileLabel.textContent = file.name;
      } else {
        this.fileLabel.textContent = 'Choose file or drag and drop';
      }
    });

    // Drag and drop functionality
    const uploadWrapper = document.querySelector('.file-upload-wrapper');
    const uploadLabel = document.querySelector('.file-upload-label');

    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
      uploadLabel.addEventListener(eventName, this.preventDefaults, false);
    });

    ['dragenter', 'dragover'].forEach(eventName => {
      uploadLabel.addEventListener(eventName, () => {
        uploadLabel.style.borderColor = '#007bff';
        uploadLabel.style.backgroundColor = '#f0f8ff';
      }, false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
      uploadLabel.addEventListener(eventName, () => {
        uploadLabel.style.borderColor = '#ddd';
        uploadLabel.style.backgroundColor = '#f8f9fa';
      }, false);
    });

    uploadLabel.addEventListener('drop', (e) => {
      const files = e.dataTransfer.files;
      if (files.length > 0) {
        this.fileInput.files = files;
        this.fileInput.dispatchEvent(new Event('change'));
      }
    }, false);
  }

  preventDefaults(e) {
    e.preventDefault();
    e.stopPropagation();
  }

  openModal(applyBtn) {
    // Get the position title from the job card
    const jobCard = applyBtn.closest('.careers-position-card');
    const positionTitle = jobCard ? jobCard.querySelector('h3').textContent : 'Position';
    
    this.positionInput.value = positionTitle;
    this.modal.style.display = 'block';
    document.body.style.overflow = 'hidden';
    
    // Focus on first input
    setTimeout(() => {
      document.getElementById('firstName').focus();
    }, 100);
  }

  closeModal() {
    this.modal.style.display = 'none';
    document.body.style.overflow = 'auto';
    this.resetForm();
  }

  resetForm() {
    this.form.reset();
    this.fileLabel.textContent = 'Choose file or drag and drop';
    this.hideLoading();
  }

  showLoading() {
    this.submitBtn.disabled = true;
    this.submitBtn.querySelector('.btn-text').style.display = 'none';
    this.submitBtn.querySelector('.btn-loading').style.display = 'flex';
  }

  hideLoading() {
    this.submitBtn.disabled = false;
    this.submitBtn.querySelector('.btn-text').style.display = 'inline';
    this.submitBtn.querySelector('.btn-loading').style.display = 'none';
  }

  validateForm() {
    const requiredFields = [
      'firstName', 'lastName', 'email', 'position', 
      'experience', 'availability', 'resume', 'consent'
    ];

    for (const fieldName of requiredFields) {
      const field = document.getElementById(fieldName);
      if (!field.value || (field.type === 'checkbox' && !field.checked)) {
        field.focus();
        alert(`Please fill in the ${fieldName.replace(/([A-Z])/g, ' $1').toLowerCase()} field.`);
        return false;
      }
    }

    // Validate email format
    const email = document.getElementById('email').value;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      document.getElementById('email').focus();
      alert('Please enter a valid email address.');
      return false;
    }

    return true;
  }

  async handleSubmit() {
    if (!this.validateForm()) {
      return;
    }

    this.showLoading();

    try {
      // Collect form data
      const formData = new FormData(this.form);
      
      // Add additional fields for Formspree
      formData.append('_subject', `New Job Application: ${formData.get('position')}`);
      formData.append('_replyto', formData.get('email'));
      
      // Submit to Formspree
      const response = await fetch(this.form.action, {
        method: 'POST',
        body: formData,
        headers: {
          'Accept': 'application/json'
        }
      });
      
      if (response.ok) {
        // Show success message
        alert('Application submitted successfully! We will review your application and get back to you soon.');
        this.closeModal();
      } else {
        throw new Error('Form submission failed');
      }
      
    } catch (error) {
      console.error('Submission error:', error);
      alert('There was an error submitting your application. Please try again.');
    } finally {
      this.hideLoading();
    }
  }


}

// Initialize the application manager when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  new ApplicationManager();
});