// Mobile nav
const toggle = document.querySelector(".nav-toggle");
const nav = document.querySelector("#primary-nav");
if (toggle && nav) {
  toggle.addEventListener("click", () => {
    const isOpen = nav.classList.toggle("open");
    toggle.setAttribute("aria-expanded", String(isOpen));
    toggle.classList.toggle("menu-open", isOpen);
  });
}

// Footer year
const yearEl = document.getElementById("year");
if (yearEl) yearEl.textContent = new Date().getFullYear();

// Contact form UX
const contactForm = document.getElementById("contact-form");
const contactNote = document.getElementById("contact-note");
const contactFormIndex = document.getElementById("contact-form-index");
const contactNoteIndex = document.getElementById("contact-note-index");
const contactFormApproach = document.getElementById("contact-form-approach");
const contactNoteApproach = document.getElementById("contact-note-approach");

if (contactForm) {
  contactForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const formData = new FormData(contactForm);
    
    // Add form type for the PHP handler
    formData.append('form_type', 'contact');
    
    // Get form data
    const data = Object.fromEntries(formData.entries());

    // Front-end validation
    if (!data.fullname || !data.email || !data.message) {
      contactNote.textContent = "Please fill in name, email, and message.";
      contactNote.style.color = "var(--error)";
      return;
    }
    
    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email)) {
      contactNote.textContent = "Please enter a valid email address.";
      contactNote.style.color = "var(--error)";
      return;
    }
    
    // Show loading state
    const submitBtn = contactForm.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = 'Sending... <i class="fas fa-spinner fa-spin"></i>';
    submitBtn.disabled = true;
    contactNote.textContent = "Sending your message...";
    contactNote.style.color = "var(--primary)";
    
    try {
      // Send to Hostinger email handler
      const response = await fetch('email-handler.php', {
        method: 'POST',
        body: formData
      });
      
      const result = await response.json();
      
      if (result.success) {
        contactNote.textContent = result.message || "Thanks! We'll get back to you soon.";
        contactNote.style.color = "var(--success)";
        contactForm.reset();
      } else {
        throw new Error(result.message || 'Failed to send message');
      }
    } catch (error) {
      console.error('Contact form error:', error);
      contactNote.textContent = "Sorry, there was an error sending your message. Please try again or contact us directly.";
      contactNote.style.color = "var(--error)";
    } finally {
      // Reset button state
      submitBtn.innerHTML = originalText;
      submitBtn.disabled = false;
    }
  });
}

// Contact form UX for index
if (contactFormIndex) {
  contactFormIndex.addEventListener("submit", async (e) => {
    e.preventDefault();
    const formData = new FormData(contactFormIndex);
    
    // Add form type for the PHP handler
    formData.append('form_type', 'contact');
    
    // Get form data
    const data = Object.fromEntries(formData.entries());

    // Front-end validation
    if (!data.fullname || !data.email || !data.message) {
      contactNoteIndex.textContent = "Please fill in name, email, and message.";
      contactNoteIndex.style.color = "var(--error)";
      return;
    }
    
    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email)) {
      contactNoteIndex.textContent = "Please enter a valid email address.";
      contactNoteIndex.style.color = "var(--error)";
      return;
    }
    
    // Show loading state
    const submitBtn = contactFormIndex.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = 'Sending... <i class="fas fa-spinner fa-spin"></i>';
    submitBtn.disabled = true;
    contactNoteIndex.textContent = "Sending your message...";
    contactNoteIndex.style.color = "var(--primary)";
    
    try {
      // Send to Hostinger email handler
      const response = await fetch('email-handler.php', {
        method: 'POST',
        body: formData
      });
      
      const result = await response.json();
      
      if (result.success) {
        contactNoteIndex.textContent = result.message || "Thanks! We'll get back to you soon.";
        contactNoteIndex.style.color = "var(--success)";
        contactFormIndex.reset();
      } else {
        throw new Error(result.message || 'Failed to send message');
      }
    } catch (error) {
      console.error('Contact form error:', error);
      contactNoteIndex.textContent = "Sorry, there was an error sending your message. Please try again or contact us directly.";
      contactNoteIndex.style.color = "var(--error)";
    } finally {
      // Reset button state
      submitBtn.innerHTML = originalText;
      submitBtn.disabled = false;
    }
  });
}

// Contact form UX for approach
if (contactFormApproach) {
  contactFormApproach.addEventListener("submit", async (e) => {
    e.preventDefault();
    const formData = new FormData(contactFormApproach);
    
    // Add form type for the PHP handler
    formData.append('form_type', 'contact');
    
    // Get form data
    const data = Object.fromEntries(formData.entries());

    // Front-end validation
    if (!data.fullname || !data.email || !data.message) {
      contactNoteApproach.textContent = "Please fill in name, email, and message.";
      contactNoteApproach.style.color = "var(--error)";
      return;
    }
    
    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email)) {
      contactNoteApproach.textContent = "Please enter a valid email address.";
      contactNoteApproach.style.color = "var(--error)";
      return;
    }
    
    // Show loading state
    const submitBtn = contactFormApproach.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = 'Sending... <i class="fas fa-spinner fa-spin"></i>';
    submitBtn.disabled = true;
    contactNoteApproach.textContent = "Sending your message...";
    contactNoteApproach.style.color = "var(--primary)";
    
    try {
      // Send to Hostinger email handler
      const response = await fetch('email-handler.php', {
        method: 'POST',
        body: formData
      });
      
      const result = await response.json();
      
      if (result.success) {
        contactNoteApproach.textContent = result.message || "Thanks! We'll get back to you soon.";
        contactNoteApproach.style.color = "var(--success)";
        contactFormApproach.reset();
      } else {
        throw new Error(result.message || 'Failed to send message');
      }
    } catch (error) {
      console.error('Contact form error:', error);
      contactNoteApproach.textContent = "Sorry, there was an error sending your message. Please try again or contact us directly.";
      contactNoteApproach.style.color = "var(--error)";
    } finally {
      // Reset button state
      submitBtn.innerHTML = originalText;
      submitBtn.disabled = false;
    }
  });
}

// Newsletter form UX
const newsletterForm = document.getElementById("newsletter-form");
const newsletterNote = document.getElementById("newsletter-note");
const emailInput = document.getElementById('email-input');
const errorMessage = document.getElementById('error-message');

if (newsletterForm) {
  // Real-time validation
  if (emailInput && errorMessage) {
    emailInput.addEventListener('blur', function () {
      validateEmail();
    });

    emailInput.addEventListener('input', function () {
      if (this.classList.contains('error')) {
        validateEmail();
      }
    });
  }

  newsletterForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const formData = new FormData(newsletterForm);
    
    // Add form type for the PHP handler
    formData.append('form_type', 'newsletter');
    
    const data = Object.fromEntries(formData.entries());

    if (emailInput && errorMessage) {
      if (validateEmail()) {
        // Show loading state
        const submitBtn = newsletterForm.querySelector('button[type="submit"]');
        const originalText = submitBtn.innerHTML;
        submitBtn.innerHTML = 'Subscribing...';
        submitBtn.disabled = true;
        
        try {
          // Send to dedicated newsletter handler
          const response = await fetch('newsletter-handler.php', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email: data.email })
          });
          
          const result = await response.json();
          
          if (result.success) {
            newsletterNote.textContent = result.message || "Thanks for subscribing!";
            newsletterNote.style.color = "var(--success)";
            newsletterForm.reset();
            errorMessage.style.display = 'none';
            emailInput.classList.remove('error');
          } else {
            throw new Error(result.message || 'Failed to subscribe');
          }
        } catch (error) {
          console.error('Newsletter form error:', error);
          newsletterNote.textContent = "Sorry, there was an error. Please try again.";
          newsletterNote.style.color = "var(--error)";
        } finally {
          // Reset button state
          submitBtn.innerHTML = originalText;
          submitBtn.disabled = false;
        }
      }
    } else {
      // Fallback to original validation
      if (!data.email) {
        newsletterNote.textContent = "Please enter a valid email.";
        newsletterNote.style.color = "var(--error)";
        return;
      }
      newsletterNote.textContent = "Thanks for subscribing!";
      newsletterNote.style.color = "var(--success)";
      newsletterForm.reset();
    }
  });

  function validateEmail() {
    const email = emailInput.value.trim();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (email === '') {
      showError('Please enter an email address');
      return false;
    } else if (!emailRegex.test(email)) {
      showError('Please enter a valid email address');
      return false;
    } else {
      hideError();
      return true;
    }
  }

  function showError(message) {
    errorMessage.textContent = message;
    errorMessage.style.display = 'block';
    emailInput.classList.add('error');
  }

  function hideError() {
    errorMessage.style.display = 'none';
    emailInput.classList.remove('error');
  }
}

// Page Loader for Navigation
function createPageLoader() {
  const loader = document.createElement('div');
  loader.className = 'page-loader';
  loader.innerHTML = '<div class="loader-spinner"></div>';
  document.body.appendChild(loader);
  return loader;
}

function showPageLoader() {
  const loader = document.querySelector('.page-loader') || createPageLoader();
  loader.classList.add('active');
  return loader;
}

function hidePageLoader() {
  const loader = document.querySelector('.page-loader');
  if (loader) {
    loader.classList.remove('active');
  }
}

// Handle navigation links with loader
function handleNavigationClick(e) {
  const link = e.target.closest('a');
  if (!link) return;

  const href = link.getAttribute('href');

  // Check if it's an internal page link (not external or anchor)
  if (href &&
    !href.startsWith('http') &&
    !href.startsWith('mailto:') &&
    !href.startsWith('tel:') &&
    !href.startsWith('#') &&
    href.endsWith('')) {

    e.preventDefault();

    // Show loader
    showPageLoader();

    // Navigate after 1 second
    setTimeout(() => {
      window.location.href = href;
    }, 1000);
  }
}

// Add event listeners to navigation links
document.addEventListener('DOMContentLoaded', () => {
  // Add click listeners to navigation
  const navLinks = document.querySelectorAll('.nav-list a, .brand, .nav-cta');
  navLinks.forEach(link => {
    link.addEventListener('click', handleNavigationClick);
  });

  // Hide loader when page loads
  hidePageLoader();
});

// Hide loader when page loads (fallback)
window.addEventListener('load', () => {
  hidePageLoader();
});

/* // Smooth scrolling for navigation links */
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    e.preventDefault();
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      target.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
      });
    }
  });
});

/* // Add scroll effect to header */
window.addEventListener('scroll', function () {
  const header = document.querySelector('.header');
  if (window.scrollY > 100) {
    header.style.background = 'rgba(255, 255, 255, 0.95)';
    header.style.backdropFilter = 'blur(10px)';
  } else {
    header.style.background = 'white';
    header.style.backdropFilter = 'none';
  }
});

/* // Animate job listings on scroll */
const observerOptions = {
  threshold: 0.1,
  rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver(function (entries) {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = '1';
      entry.target.style.transform = 'translateY(0)';
    }
  });
}, observerOptions);

/* // Observe job listings for animation */
document.querySelectorAll('.careers-job-listing').forEach(listing => {
  listing.style.opacity = '0';
  listing.style.transform = 'translateY(20px)';
  listing.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
  observer.observe(listing);
});

/* // Observe perk items for animation */
document.querySelectorAll('.careers-perk-item').forEach(item => {
  item.style.opacity = '0';
  item.style.transform = 'translateY(20px)';
  item.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
  observer.observe(item);
});

/* // Handle apply button clicks */
document.querySelectorAll('.careers-apply-btn').forEach(btn => {
  btn.addEventListener('click', function (e) {
    e.preventDefault();
    alert('Application form would open here. This is a demo implementation.');
  });
});

/* // Add hover effects to job listings */
document.querySelectorAll('.careers-job-listing').forEach(listing => {
  listing.addEventListener('mouseenter', function () {
    this.style.borderColor = '#000';
  });

  listing.addEventListener('mouseleave', function () {
    this.style.borderColor = '#e0e0e0';
  });
});