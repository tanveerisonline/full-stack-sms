// Blog Search and Filter Functionality
class BlogManager {
  constructor() {
    this.posts = [];
    this.filteredPosts = [];
    this.currentFilter = 'All';
    this.searchQuery = '';
    this.init();
  }

  init() {
    this.collectPosts();
    this.bindEvents();
    this.filteredPosts = [...this.posts];
  }

  collectPosts() {
    const postElements = document.querySelectorAll('.post-card, .post-card-large');
    this.posts = Array.from(postElements).map(post => {
      const category = post.querySelector('.post-card-meta span:first-child')?.textContent || 'All';
      const title = post.querySelector('.post-card-title')?.textContent || '';
      const content = post.querySelector('p')?.textContent || '';
      const date = post.querySelector('.post-card-author span:last-child, small')?.textContent || '';
      
      return {
        element: post,
        category: category.trim(),
        title: title.trim(),
        content: content.trim(),
        date: date.trim(),
        searchText: `${title} ${content} ${category}`.toLowerCase()
      };
    });
  }

  bindEvents() {
    // Read more buttons
    this.bindReadMoreButtons();
    
    // Filter toggle button
    const filterToggle = document.getElementById('filterToggle');
    const filterSection = document.getElementById('filterSection');
    
    if (filterToggle && filterSection) {
      filterToggle.addEventListener('click', (e) => {
        e.preventDefault();
        const isVisible = filterSection.style.display !== 'none';
        filterSection.style.display = isVisible ? 'none' : 'block';
      });
    }

    // Filter pills
    const filterPills = document.querySelectorAll('.filter-pill:not(.date-filter)');
    filterPills.forEach(pill => {
      pill.addEventListener('click', (e) => {
        e.preventDefault();
        this.handleFilterClick(pill);
      });
    });

    // Date filter pills
    const dateFilterPills = document.querySelectorAll('.filter-pill.date-filter');
    dateFilterPills.forEach(pill => {
      pill.addEventListener('click', (e) => {
        e.preventDefault();
        this.handleDateFilterClick(pill);
      });
    });

    // Search functionality
    const searchInput = document.querySelector('.search-input');
    const searchButton = document.querySelector('.blog-search-form button, .search-button');
    
    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        this.handleSearch(e.target.value);
      });
      
      searchInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          this.handleSearch(e.target.value);
        }
      });
    }
    
    if (searchButton) {
      searchButton.addEventListener('click', (e) => {
        e.preventDefault();
        const query = searchInput ? searchInput.value : '';
        this.handleSearch(query);
      });
    }
  }

  handleFilterClick(clickedPill) {
    // Update active state for category filters
    document.querySelectorAll('.filter-pill:not(.date-filter)').forEach(pill => {
      pill.classList.remove('active');
    });
    clickedPill.classList.add('active');
    
    // Update current filter
    this.currentFilter = clickedPill.getAttribute('data-filter') || clickedPill.textContent.trim();
    
    // Apply filters
    this.applyFilters();
  }

  handleDateFilterClick(clickedPill) {
    // Update active state for date filters
    document.querySelectorAll('.filter-pill.date-filter').forEach(pill => {
      pill.classList.remove('active');
    });
    clickedPill.classList.add('active');
    
    // For now, just log the date filter (can be enhanced later)
    const dateFilter = clickedPill.getAttribute('data-date') || clickedPill.textContent.trim();
    console.log('Date filter selected:', dateFilter);
  }

  handleSearch(query) {
    this.searchQuery = query.toLowerCase().trim();
    this.applyFilters();
  }

  applyFilters() {
    this.filteredPosts = this.posts.filter(post => {
      // Category filter
      const categoryMatch = this.currentFilter === 'All' || 
                           post.category === this.currentFilter;
      
      // Search filter
      const searchMatch = !this.searchQuery || 
                         post.searchText.includes(this.searchQuery);
      
      return categoryMatch && searchMatch;
    });
    
    this.updateDisplay();
  }

  updateDisplay() {
    // Hide all posts first
    this.posts.forEach(post => {
      post.element.style.display = 'none';
    });
    
    // Show filtered posts
    this.filteredPosts.forEach(post => {
      post.element.style.display = 'block';
    });
    
    // Update results count or show no results message
    this.updateResultsMessage();
  }

  updateResultsMessage() {
    let messageContainer = document.querySelector('.search-results-message');
    
    if (!messageContainer) {
      messageContainer = document.createElement('div');
      messageContainer.className = 'search-results-message';
      messageContainer.style.cssText = `
        text-align: center;
        padding: 2rem;
        color: var(--gray);
        font-size: 1.1rem;
        grid-column: 1 / -1;
      `;
      
      const blogGrid = document.querySelector('.blog-grid');
      if (blogGrid) {
        blogGrid.appendChild(messageContainer);
      }
    }
    
    if (this.filteredPosts.length === 0) {
      let message = 'No posts found';
      if (this.searchQuery && this.currentFilter !== 'All') {
        message = `No posts found for "${this.searchQuery}" in ${this.currentFilter}`;
      } else if (this.searchQuery) {
        message = `No posts found for "${this.searchQuery}"`;
      } else if (this.currentFilter !== 'All') {
        message = `No posts found in ${this.currentFilter}`;
      }
      
      messageContainer.innerHTML = `
        <div style="background: white; padding: 3rem; border-radius: 12px; box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);">
          <i class="fas fa-search" style="font-size: 3rem; color: #999; margin-bottom: 1rem;"></i>
          <h3 style="margin-bottom: 1rem; color: #000;">${message}</h3>
          <p>Try adjusting your search terms or filters to find what you're looking for.</p>
        </div>
      `;
      messageContainer.style.display = 'block';
    } else {
      messageContainer.style.display = 'none';
    }
  }

  // Method to add date filter functionality
  addDateFilter() {
    const dateFilter = document.createElement('select');
    dateFilter.className = 'date-filter';
    dateFilter.style.cssText = `
      padding: 0.5rem 1rem;
      border: 1px solid var(--gray-light);
      border-radius: 25px;
      font-size: 0.85rem;
      background: white;
      cursor: pointer;
      margin-left: 1rem;
    `;
    
    dateFilter.innerHTML = `
      <option value="all">All Dates</option>
      <option value="week">Past Week</option>
      <option value="month">Past Month</option>
      <option value="year">Past Year</option>
    `;
    
    const blogSearch = document.querySelector('.blog-search');
    if (blogSearch) {
      blogSearch.appendChild(dateFilter);
    }
    
    dateFilter.addEventListener('change', (e) => {
      this.handleDateFilter(e.target.value);
    });
  }

  handleDateFilter(period) {
    // This would require actual date parsing from posts
    // For now, it's a placeholder for future enhancement
    console.log(`Date filter: ${period}`);
  }

  bindReadMoreButtons() {
    const readMoreButtons = document.querySelectorAll('.read-more-btn');
    
    readMoreButtons.forEach(button => {
      button.addEventListener('click', (e) => {
        e.preventDefault();
        this.handleReadMoreClick(button);
      });
    });
  }

  handleReadMoreClick(button) {
    // Get the blog post title from the card
    const postCard = button.closest('.post-card, .post-card-large');
    if (!postCard) return;
    
    const titleElement = postCard.querySelector('.post-card-title');
    if (!titleElement) return;
    
    // Normalize the title by removing extra whitespace and line breaks
    const title = titleElement.textContent.replace(/\s+/g, ' ').trim();
    
    // Map blog titles to their corresponding HTML files
    const blogUrlMap = {
      'How AI is Revolutionizing Creative Marketing Strategies': 'ai-creativity-marketing',
      'The Complete Guide to A/B Testing Your Marketing Campaigns': 'ab-testing-guide',
      'Beyond the Funnel: Building a Customer-Centric Marketing Ecosystem': 'customer-centric-marketing',
      'The Future of Search: How Generative AI is Shaping SEO Strategy': 'future-search-ai-seo',
      'LinkedIn Ads vs. TikTok Ads: Which Is Right for Your B2B Brand?': 'linkedin-vs-tiktok-ads',
      'The Power of Personalization: How to Use Data to Create Hyper-Relevant Experiences': 'personalization-data-experiences',
      '2024\'s Biggest Digital Marketing Trend: What It Is & How to Prepare': 'digital-marketing-trends-2024',
      'Measuring Social Media ROI: A Data-Driven Approach': 'social-media-roi',
      'Content Marketing Trends That Will Define 2024': 'content-marketing-trends',
      'Email Marketing Automation: Nurturing Leads While You Sleep': 'email-marketing-automation'
    };
    
    const blogUrl = blogUrlMap[title];
    
    if (blogUrl) {
      // Open the individual blog post page in the same tab
      window.location.href = blogUrl;
    } else {
      console.warn('Blog URL not found for title:', title);
      // Fallback to generic blog post page in same tab
      window.location.href = 'blog-post';
    }
  }
}

// Initialize blog manager when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  const blogManager = new BlogManager();
  
  // Add date filter if needed
  // blogManager.addDateFilter();
});

// Export for potential use in other scripts
if (typeof module !== 'undefined' && module.exports) {
  module.exports = BlogManager;
}