<?php
// Email Handler for Hostinger Email Integration
// This script handles contact forms and newsletter subscriptions

// CORS headers for cross-origin requests
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit();
}

// Configuration - UPDATE THESE WITH YOUR HOSTINGER EMAIL SETTINGS
$config = [
    'smtp_host' => 'smtp.hostinger.com',
    'smtp_port' => 587,
    'smtp_username' => 'contact@thenexgendigital.com', // Replace with your Hostinger email
    'smtp_password' => 'Cracken@@alpha3264', // Replace with your email password
    'from_email' => 'contact@thenexgendigital.com', // Replace with your Hostinger email
    'from_name' => 'The Next Gen Digital',
    'to_email' => 'contact@thenexgendigital.com', // Replace with where you want to receive emails
    'to_name' => 'The Next Gen Digital Team'
];

// Input validation and sanitization
function sanitizeInput($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Send email function using PHP's mail() or SMTP
function sendEmail($to, $subject, $message, $headers) {
    // Using PHP's built-in mail() function
    // For better reliability, consider using PHPMailer with SMTP
    return mail($to, $subject, $message, $headers);
}

// Get form type from POST data
$formType = isset($_POST['form_type']) ? sanitizeInput($_POST['form_type']) : 'contact';

try {
    switch ($formType) {
        case 'contact':
            handleContactForm();
            break;
        case 'newsletter':
            handleNewsletterForm();
            break;
        default:
            throw new Exception('Invalid form type');
    }
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage()
    ]);
}

function handleContactForm() {
    global $config;
    
    // Required fields validation
    $requiredFields = ['fullname', 'email', 'message'];
    foreach ($requiredFields as $field) {
        if (empty($_POST[$field])) {
            throw new Exception("Field '{$field}' is required");
        }
    }
    
    // Sanitize and validate input
    $fullname = sanitizeInput($_POST['fullname']);
    $email = sanitizeInput($_POST['email']);
    $company = isset($_POST['company']) ? sanitizeInput($_POST['company']) : '';
    $phone = isset($_POST['phone']) ? sanitizeInput($_POST['phone']) : '';
    $message = sanitizeInput($_POST['message']);
    
    if (!validateEmail($email)) {
        throw new Exception('Invalid email address');
    }
    
    // Create email content
    $subject = 'New Contact Form Submission - The Next Gen Digital';
    $emailBody = "
    <html>
    <head>
        <title>New Contact Form Submission</title>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: #2563eb; color: white; padding: 20px; text-align: center; }
            .content { background: #f9f9f9; padding: 20px; }
            .field { margin-bottom: 15px; }
            .label { font-weight: bold; color: #555; }
            .value { margin-top: 5px; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h2>New Contact Form Submission</h2>
            </div>
            <div class='content'>
                <div class='field'>
                    <div class='label'>Name:</div>
                    <div class='value'>{$fullname}</div>
                </div>
                <div class='field'>
                    <div class='label'>Email:</div>
                    <div class='value'>{$email}</div>
                </div>
                " . ($company ? "<div class='field'><div class='label'>Company:</div><div class='value'>{$company}</div></div>" : "") . "
                " . ($phone ? "<div class='field'><div class='label'>Phone:</div><div class='value'>{$phone}</div></div>" : "") . "
                <div class='field'>
                    <div class='label'>Message:</div>
                    <div class='value'>{$message}</div>
                </div>
                <div class='field'>
                    <div class='label'>Submitted:</div>
                    <div class='value'>" . date('Y-m-d H:i:s') . "</div>
                </div>
            </div>
        </div>
    </body>
    </html>
    ";
    
    // Email headers
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: {$config['from_name']} <{$config['from_email']}>" . "\r\n";
    $headers .= "Reply-To: {$fullname} <{$email}>" . "\r\n";
    
    // Send email
    if (sendEmail($config['to_email'], $subject, $emailBody, $headers)) {
        echo json_encode([
            'success' => true,
            'message' => 'Thank you for your message! We will get back to you soon.'
        ]);
    } else {
        throw new Exception('Failed to send email');
    }
}

function handleNewsletterForm() {
    global $config;
    
    // Required fields validation
    if (empty($_POST['email'])) {
        throw new Exception('Email is required');
    }
    
    // Sanitize and validate input
    $email = sanitizeInput($_POST['email']);
    
    if (!validateEmail($email)) {
        throw new Exception('Invalid email address');
    }
    
    // Create email content
    $subject = 'New Newsletter Subscription - The Next Gen Digital';
    $emailBody = "
    <html>
    <head>
        <title>New Newsletter Subscription</title>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: #2563eb; color: white; padding: 20px; text-align: center; }
            .content { background: #f9f9f9; padding: 20px; }
            .field { margin-bottom: 15px; }
            .label { font-weight: bold; color: #555; }
            .value { margin-top: 5px; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h2>New Newsletter Subscription</h2>
            </div>
            <div class='content'>
                <div class='field'>
                    <div class='label'>Email:</div>
                    <div class='value'>{$email}</div>
                </div>
                <div class='field'>
                    <div class='label'>Subscribed:</div>
                    <div class='value'>" . date('Y-m-d H:i:s') . "</div>
                </div>
                <div class='field'>
                    <div class='label'>Source:</div>
                    <div class='value'>Website Newsletter Form</div>
                </div>
            </div>
        </div>
    </body>
    </html>
    ";
    
    // Email headers
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: {$config['from_name']} <{$config['from_email']}>" . "\r\n";
    
    // Send email
    if (sendEmail($config['to_email'], $subject, $emailBody, $headers)) {
        echo json_encode([
            'success' => true,
            'message' => 'Thank you for subscribing to our newsletter!'
        ]);
    } else {
        throw new Exception('Failed to send email');
    }
}

// Log errors (optional)
function logError($message) {
    $logFile = 'email_errors.log';
    $timestamp = date('Y-m-d H:i:s');
    file_put_contents($logFile, "[{$timestamp}] {$message}\n", FILE_APPEND | LOCK_EX);
}
?>