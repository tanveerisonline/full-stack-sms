# Formspree Integration Setup Guide

To make your careers application form fully functional, follow these steps to set up Formspree:

## Step 1: Create a Formspree Account
1. Go to [formspree.io](https://formspree.io)
2. Sign up for a free account
3. Verify your email address

## Step 2: Create a New Form
1. Click "New Form" in your Formspree dashboard
2. Give your form a name (e.g., "Career Applications")
3. Copy the form endpoint URL (it will look like: `https://formspree.io/f/YOUR_FORM_ID`)

## Step 3: Update Your Website
1. Open `careers` in your code editor
2. Find line 335 where it says:
   ```html
   <form id="applicationForm" class="application-form" action="https://formspree.io/f/YOUR_FORM_ID" method="POST" enctype="multipart/form-data">
   ```
3. Replace `YOUR_FORM_ID` with your actual Formspree form ID

## Step 4: Configure Formspree Settings (Optional)
In your Formspree dashboard, you can:
- Set up custom email templates
- Add multiple email recipients
- Configure spam protection
- Set up auto-reply messages
- Add custom redirect URLs

## Step 5: Test Your Form
1. Save your changes and refresh your website
2. Click any "Apply Now" button on the careers page
3. Fill out the form with test data
4. Submit the form
5. Check your email for the application details

## Features Included
✅ **File Upload Support**: Resume files are automatically handled
✅ **Email Notifications**: You'll receive emails with all form data
✅ **Spam Protection**: Built-in spam filtering
✅ **Mobile Responsive**: Works on all devices
✅ **Form Validation**: Client-side validation before submission
✅ **Professional Styling**: Matches your website design

## Formspree Free Plan Limits
- 50 submissions per month
- File uploads up to 10MB
- Basic spam filtering
- Email notifications

## Upgrade Options
For higher volume or additional features:
- **Gold Plan**: 1,000 submissions/month ($10/month)
- **Platinum Plan**: 5,000 submissions/month ($40/month)

## Troubleshooting

### Form Not Submitting
- Check that you've replaced `YOUR_FORM_ID` with your actual form ID
- Ensure your Formspree account is verified
- Check browser console for any JavaScript errors

### Not Receiving Emails
- Check your spam folder
- Verify the email address in your Formspree account
- Ensure the form is properly configured in Formspree dashboard

### File Upload Issues
- Ensure files are under 10MB (Formspree limit)
- Check that file types are PDF, DOC, or DOCX
- Verify your Formspree plan supports file uploads

## Support
If you need help:
- Check [Formspree Documentation](https://help.formspree.io/)
- Contact Formspree support through their dashboard
- Review browser console for error messages

---

**Note**: Once configured, your application form will send all submitted data (including uploaded resumes) directly to your email address. The form includes professional validation, file upload handling, and a great user experience.